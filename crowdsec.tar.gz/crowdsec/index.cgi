#!/usr/bin/perl
# CrowdSec Webmin Module - index.cgi  (main dashboard, tab router)

require './crowdsec-lib.pl';

&ReadParse();
my $tab          = $in{'tab'} || 'engines';

# Load config — determines defaults and test IP ranges
my @test_ranges = get_test_ip_ranges();
# Note: if @test_ranges is empty, filter_alerts will be a no-op

# exclude_test: URL param overrides config default (allows per-session toggle)
my $exclude_test = exists $in{'exclude_test'}
    ? ($in{'exclude_test'} ? 1 : 0)
    : get_exclude_by_default();

# ── Time range (applies to alerts + everything derived from them) ────────────
my %SINCE_LABELS = (
    '1h'  => 'Last 1 hour',   '24h' => 'Last 24 hours', '3d'  => 'Last 3 days',
    '7d'  => 'Last 7 days',   '15d' => 'Last 15 days',  '30d' => 'Last 30 days',
    'all' => 'All time',
);
my $since = $in{'since'} || '24h';
$since = '24h' unless exists $SINCE_LABELS{$since};
my $since_label = $SINCE_LABELS{$since};
my $since_query = ($since eq 'all') ? '' : $since;   # what we pass to cscli --since

my $qs_filter = ($exclude_test ? '&exclude_test=1' : '&exclude_test=0') . "&since=$since";

&ui_print_header(undef, "CrowdSec Security Engine", "", undef, 1, 1);

# ── Gather data up-front ──────────────────────────────────────────────────────
my $alerts_raw = get_alerts_detail($since_query);
# Apply test-IP filter if checkbox is on
my $alerts = $exclude_test
    ? filter_alerts($alerts_raw, @test_ranges)
    : $alerts_raw;
my $filtered_count = scalar(@$alerts_raw) - scalar(@$alerts);
my ($decisions, $decisions_raw_json) = get_decisions();

my $engines   = get_engine_info();
my $bouncers  = get_bouncers();
my $hub       = get_hub_counts();
my $metrics   = parse_bouncer_metrics();
my $metrics_by_origin = parse_bouncer_metrics_by_origin();
my $cs_status = get_service_status('crowdsec');
my $cb_status = get_service_status('crowdsec-firewall-bouncer');
my $cs_err    = get_service_errors('crowdsec');
my $cb_err    = get_service_errors('crowdsec-firewall-bouncer');
my $alert_cnt = scalar @$alerts;
my %_uniq_ips; $_uniq_ips{$_->{source}{ip}}++ for grep { $_->{source}{ip} } @$alerts;
my $uniq_ip_cnt = scalar keys %_uniq_ips;
my $dec_cnt   = scalar @$decisions;

# Scenario breakdown
my $sc_counts = get_scenario_counts($alerts);
my @sc_sorted = sort { $sc_counts->{$b} <=> $sc_counts->{$a} } keys %$sc_counts;

# Visualizer data — capture list, total hits, and unique count
my ($top_ips, $ip_total,  $ip_uniq)  = get_top_n($alerts, 'src_ip',   3);
my ($top_as,  $as_total,  $as_uniq)  = get_top_n($alerts, 'src_as',   3);
my ($top_eng, $eng_total, $eng_uniq) = get_top_n($alerts, 'engine',   3);
my ($top_sc,  $sc_total,  $sc_uniq)  = get_top_n($alerts, 'scenario', 3);

# Expanded lists — all entries (no top-N cutoff)
my ($exp_ips) = get_top_n($alerts, 'src_ip',   999);
my ($exp_as)  = get_top_n($alerts, 'src_as',   999);
my ($exp_eng) = get_top_n($alerts, 'engine',   999);
my ($exp_sc)  = get_top_n($alerts, 'scenario', 999);

# Generate SVG sparklines directly in Perl - no JS canvas timing issues
my ($tl_ip_s1, $tl_ip_s2, $tl_ip_m) = get_timeline_data($alerts, 'src_ip', $since);
my ($tl_as_s1, $tl_as_s2, $tl_as_m) = get_timeline_data($alerts, 'src_as', $since);
my ($tl_eng_s1, $tl_eng_s2, $tl_eng_m) = get_timeline_data($alerts, 'engine', $since);
my ($tl_sc_s1, $tl_sc_s2, $tl_sc_m) = get_timeline_data($alerts, 'scenario', $since);

my $svg_ip  = svg_sparkline($tl_ip_s1, $tl_ip_s2, 300, 64, $tl_ip_m);
my $svg_as  = svg_sparkline($tl_as_s1, $tl_as_s2, 300, 64, $tl_as_m);
my $svg_eng = svg_sparkline($tl_eng_s1, $tl_eng_s2, 300, 64, $tl_eng_m);
my $svg_sc  = svg_sparkline($tl_sc_s1, $tl_sc_s2, 300, 64, $tl_sc_m);

# Engine name/id for tooltip - match console style "Security Engine ...Xkkp"
my ($eng_name, $eng_id) = ('N/A', 'N/A');
if (@$engines) {
    my $e      = $engines->[0];
    my $mid    = $e->{machine_id} || '';
    my $nm     = $e->{name}       || '';
    # Use short name if it's a real short name (not the full machine ID repeated)
    my $suffix = ($nm && length($nm) <= 20 && $nm ne $mid) ? $nm : ('...' . substr($mid, -4));
    $eng_name  = "Security Engine ...$suffix";
    $eng_id    = $mid;
}

# ── Scenario colour palette (matches console) ─────────────────────────────────
my @SC_COLORS = ('#6366f1','#f59e0b','#a78bfa','#06b6d4','#ec4899',
                 '#10b981','#f97316','#84cc16','#e11d48','#0ea5e9');


# ── CSS + shell ───────────────────────────────────────────────────────────────
print <<'HTML';
<style>
:root{
  --bg:#0d1117;--surface:#161b27;--surface2:#1c2333;--surface3:#242d3f;
  --border:#2a3450;--border2:#344060;
  --accent:#6c63ff;--accent2:#f5a623;--accent3:#4ecdc4;
  --danger:#ff5c5c;--success:#3dd68c;--warning:#f5a623;--info:#58a6ff;
  --text:#e6edf3;--text2:#8b949e;--text3:#6e7681;
  --mono:ui-monospace,SFMono-Regular,Menlo,Consolas,'Liberation Mono',monospace;--sans:system-ui,-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
  --radius:10px;
}
*{box-sizing:border-box;margin:0;padding:0}
/* Force our colours to beat Webmin's own stylesheet */
.shell, .shell *{color:inherit}
body{background:#0d1117!important;color:#e6edf3!important;font-family:var(--sans);font-size:14px;min-height:100vh}
.shell{color:#e6edf3}
.content, .card, .card-body, .card-header, .topbar, .sidebar{color:#e6edf3}
.tbl td{color:#e6edf3!important}
.page-title{color:#e6edf3!important;font-size:20px;font-weight:700}
.card-title{color:#e6edf3!important;font-size:14px;font-weight:700}
.section-title{color:#e6edf3!important;font-size:16px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
body::before{content:'';position:fixed;inset:0;
  background:radial-gradient(ellipse 80% 50% at 50% -20%,rgba(108,99,255,0.12),transparent);
  pointer-events:none;z-index:0}

/* ── Layout ── */
.shell{position:relative;z-index:1;display:flex;min-height:100vh}
.sidebar{width:220px;flex-shrink:0;background:var(--surface);border-right:1px solid var(--border);
  display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.main{flex:1;overflow:auto}

/* ── Sidebar ── */
.sb-brand{padding:20px 16px 12px;display:flex;align-items:center;gap:10px;
  border-bottom:1px solid var(--border)}
.sb-brand .logo{width:36px;height:36px;background:linear-gradient(135deg,var(--accent),#9b59b6);
  border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:18px;
  box-shadow:0 0 16px rgba(108,99,255,.4)}
.sb-brand h2{font-size:15px;font-weight:700;letter-spacing:-.3px}
.sb-brand p{font-size:10px;color:var(--text3);font-family:var(--mono);margin-top:1px}

.sb-section{padding:8px 0}
.sb-label{font-size:10px;font-weight:600;color:var(--text3);letter-spacing:.1em;
  text-transform:uppercase;padding:8px 16px 4px}
.sb-item{display:flex;align-items:center;gap:10px;padding:8px 16px;
  color:var(--text2);cursor:pointer;border:none;background:none;
  width:100%;text-align:left;font-size:13px;font-family:var(--sans);
  text-decoration:none;transition:all .15s;border-left:2px solid transparent}
.sb-item:hover{background:var(--surface2);color:var(--text)}
.sb-item.active{background:rgba(108,99,255,.12);color:var(--accent);
  border-left-color:var(--accent);font-weight:600}
.sb-item .ico{width:18px;text-align:center;font-size:15px}
.sb-item .badge{margin-left:auto;background:var(--surface3);color:var(--text2);
  font-family:var(--mono);font-size:10px;padding:1px 6px;border-radius:10px}
.sb-item.active .badge{background:rgba(108,99,255,.25);color:var(--accent)}

.sb-svc{padding:12px 16px;border-top:1px solid var(--border);margin-top:auto}
.svc-row{display:flex;align-items:center;justify-content:space-between;
  padding:6px 0;font-size:12px}
.svc-name{color:var(--text2);font-family:var(--mono);font-size:11px}
.dot{width:7px;height:7px;border-radius:50%;display:inline-block;margin-right:4px}
.dot.on {background:var(--success);box-shadow:0 0 6px var(--success)}
.dot.off{background:var(--danger); box-shadow:0 0 6px var(--danger)}
.dot.unk{background:var(--text3)}

/* ── Top bar ── */
.topbar{display:flex;align-items:center;justify-content:space-between;
  padding:16px 28px;border-bottom:1px solid var(--border);background:var(--surface)}
.page-title .ico{font-size:22px}
.topbar-right{display:flex;align-items:center;gap:10px}
/* Exclude test IPs toggle */
.test-filter{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:600;
  padding:5px 12px;border-radius:7px;border:1px solid var(--border);
  background:var(--surface2);cursor:pointer;user-select:none;transition:all .15s;
  color:#8b949e;text-decoration:none}
.test-filter:hover{border-color:rgba(108,99,255,0.4);color:#e6edf3}
.test-filter.active{background:rgba(108,99,255,0.12);border-color:rgba(108,99,255,0.4);color:var(--accent)}
.test-filter .tf-dot{width:8px;height:8px;border-radius:50%;background:#3c4454;
  transition:background .15s;flex-shrink:0}
.test-filter.active .tf-dot{background:var(--accent);box-shadow:0 0 6px var(--accent)}
.filter-badge{display:inline-flex;align-items:center;gap:4px;font-family:var(--mono);
  font-size:10px;background:rgba(240,180,41,0.12);color:var(--warning);
  border:1px solid rgba(240,180,41,0.25);padding:2px 8px;border-radius:12px}
.btn{font-family:var(--sans);font-size:12px;font-weight:600;padding:7px 14px;
  border-radius:7px;border:none;cursor:pointer;transition:all .15s;text-decoration:none;display:inline-flex;align-items:center;gap:6px}
.btn-primary{background:#6c63ff!important;color:#fff!important;border:1px solid #6c63ff!important;text-shadow:none!important;background-image:none!important}
.btn-primary:hover{background:#7c74ff!important;border-color:#7c74ff!important;color:#fff!important}
.btn-ghost{background:var(--surface2);color:var(--text2);border:1px solid var(--border)}
.btn-ghost:hover{border-color:var(--border2);color:var(--text)}
.btn-sm{padding:5px 10px;font-size:11px}
.btn-danger{background:rgba(255,92,92,.12);color:var(--danger);border:1px solid rgba(255,92,92,.25)}
.btn-danger:hover{background:rgba(255,92,92,.22)}
.btn-success{background:rgba(61,214,140,.12);color:var(--success);border:1px solid rgba(61,214,140,.25)}
.btn-success:hover{background:rgba(61,214,140,.22)}
.btn-warn{background:rgba(245,166,35,.12);color:var(--warning);border:1px solid rgba(245,166,35,.25)}
.btn-warn:hover{background:rgba(245,166,35,.22)}

/* ── Content area ── */
.content{padding:24px 28px;max-width:1400px}

/* ── Stat cards ── */
.stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-bottom:24px;margin-top:4px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px 20px}
.stat-card .label{font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px}
.stat-card .value{font-size:30px;font-weight:700;font-family:var(--mono);line-height:1;color:#e6edf3}
.stat-card .sub{font-size:11px;color:#6e7681;margin-top:6px}
.stat-card.accent .value{color:var(--accent)}
.stat-card.danger .value{color:var(--danger)}
.stat-card.success .value{color:var(--success)}
.stat-card.warn .value{color:var(--warning)}

/* ── Section cards ── */
.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);margin-bottom:20px}
.card-header{display:flex;align-items:center;justify-content:space-between;
  padding:16px 20px;border-bottom:1px solid var(--border)}
.card-body{padding:20px}
.card-body.no-pad{padding:0}

/* ── Tables ── */
.tbl{width:100%;border-collapse:collapse;font-size:13px}
.tbl th{text-align:left;padding:10px 16px;color:var(--text3);font-size:11px;
  letter-spacing:.08em;text-transform:uppercase;font-weight:600;
  border-bottom:1px solid var(--border);background:var(--surface2)}
.tbl td{padding:11px 16px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
.tbl tr:last-child td{border-bottom:none}
.tbl tr:hover td{background:rgba(108,99,255,.04)}
.tbl .mono{font-family:var(--mono);font-size:12px}

/* ── Tags / badges ── */
.tag{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:5px;
  font-size:11px;font-weight:600;font-family:var(--mono)}
.tag.ban{background:rgba(255,92,92,.12);color:var(--danger);border:1px solid rgba(255,92,92,.2)}
.tag.captcha{background:rgba(245,166,35,.12);color:var(--warning);border:1px solid rgba(245,166,35,.2)}
.tag.scenario{background:rgba(108,99,255,.12);color:#a99cff;border:1px solid rgba(108,99,255,.2)}
.tag.active{background:rgba(61,214,140,.1);color:var(--success);border:1px solid rgba(61,214,140,.2)}
.tag.inactive{background:rgba(255,92,92,.08);color:var(--danger);border:1px solid rgba(255,92,92,.15)}

/* ── Visualizer ── */
.viz-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.viz-card{background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius);padding:16px;position:relative}
.viz-card-title{font-size:12px;font-weight:700;color:var(--accent);margin-bottom:12px;
  display:flex;align-items:center;gap:8px}
.chart-wrap{margin-bottom:12px;width:100%;display:block}
.spk{position:relative}
.spk-axis{display:flex;justify-content:space-between;font-size:10px;color:#6e7681;margin-top:4px;font-variant-numeric:tabular-nums}
.spk-empty{position:absolute;left:0;right:0;top:22px;text-align:center;font-size:11px;color:#6e7681}
.spk-hit{fill:transparent;cursor:crosshair}
.spk-hit:hover{fill:rgba(255,255,255,.07)}
.sbar-seg{transition:filter .12s}
.sbar-seg:hover{filter:brightness(1.25)}
.chart-wrap canvas{display:block;width:100%;height:90px;box-sizing:content-box}
.ranked-list{list-style:none}
.ranked-item{display:flex;align-items:center;gap:9px;padding:7px 0;
  border-bottom:1px solid rgba(255,255,255,.04);font-size:12px}
.ranked-item:last-child{border-bottom:none}
.rank-badge{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;
  justify-content:center;font-family:var(--mono);font-size:9px;font-weight:700;flex-shrink:0}
.r1{background:rgba(124,116,255,.25);color:#a49dff;border:1px solid rgba(124,116,255,.45)}
.r2{background:rgba(217,118,63,.2);color:#e8935f;border:1px solid rgba(217,118,63,.4)}
.r3{background:rgba(139,148,158,.15);color:var(--text3);border:1px solid var(--border)}
.r4{background:transparent;color:var(--text3);border:1px solid var(--border)}
.ranked-label{font-family:var(--mono);font-size:11px;flex:1;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ranked-count{font-family:var(--mono);font-size:10px;color:var(--text3);
  background:var(--bg);padding:2px 6px;border-radius:4px;flex-shrink:0}

/* ── Engine card ── */
.engine-card{background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius);padding:20px;display:flex;flex-direction:column;gap:12px}
.engine-header{display:flex;align-items:flex-start;justify-content:space-between}
.engine-id{font-family:var(--mono);font-size:10px;color:var(--text3);margin-top:2px}
.engine-stats{display:flex;gap:16px}
.engine-stat{text-align:center}
.engine-stat .n{font-size:22px;font-weight:700;font-family:var(--mono);color:var(--text)}
.engine-stat .l{font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em}
.engine-spark{height:60px;width:200px}

/* ── Stacked bar chart ── */
.sbar-chart-wrap{height:160px;position:relative;margin:16px 0}

/* ── Progress bar ── */
.pbar-wrap{margin-bottom:10px}
.pbar-header{display:flex;justify-content:space-between;margin-bottom:4px;font-size:12px}
.pbar-header .name{color:var(--text2)}
.pbar-header .vals{color:var(--text3);font-family:var(--mono);font-size:11px}
.pbar-track{height:5px;background:var(--surface3);border-radius:3px;overflow:hidden}
.pbar-fill{height:100%;border-radius:3px;transition:width .4s}

/* ── Decision duration colouring ── */
.dur-urgent{color:var(--warning)}
.dur-ok{color:var(--text2)}

/* ── Service control buttons — Stop is neutral not red (not a destructive action warning) ── */
.btn-stop-svc{background:var(--surface2);color:#8b949e;border:1px solid var(--border2)}
.btn-stop-svc:hover{border-color:#6e7681;color:var(--text)}

/* ── Error box ── */
.err-box{background:rgba(255,92,92,.07);border:1px solid rgba(255,92,92,.2);
  border-radius:8px;padding:10px 14px;font-family:var(--mono);font-size:11px;
  color:#ff9090;line-height:1.6;max-height:110px;overflow-y:auto;
  white-space:pre-wrap;word-break:break-all;margin-top:12px}
.err-label{font-size:10px;font-weight:700;color:var(--danger);
  letter-spacing:.1em;text-transform:uppercase;margin-bottom:5px;display:flex;align-items:center;gap:5px}

/* ── Tooltip ── */
.tooltip-box{background:var(--surface3);border:1px solid var(--border2);border-radius:8px;
  padding:10px 14px;font-family:var(--mono);font-size:11px;color:var(--text2);
  display:none;position:absolute;z-index:200;min-width:260px;
  box-shadow:0 8px 32px rgba(0,0,0,.5)}
.tb-row{margin-bottom:3px}.tb-row:last-child{margin-bottom:0}
.tb-val{color:var(--text);font-weight:600}

/* ── Alert quota banner ── */
.quota-banner{background:rgba(245,166,35,.08);border:1px solid rgba(245,166,35,.25);
  border-radius:var(--radius);padding:12px 18px;display:flex;align-items:center;
  justify-content:space-between;margin-bottom:20px;gap:12px}
.quota-text p{font-size:13px;font-weight:600;color:var(--warning)}
.quota-text span{font-size:11px;color:var(--text3)}
.quota-count{font-family:var(--mono);font-size:13px;color:var(--text2);text-align:right}

/* ── Tabs (Visualizer) ── */
.viz-tabs{display:flex;gap:3px;background:var(--bg);border:1px solid var(--border);
  border-radius:7px;padding:3px}
.viz-tab{font-size:11px;font-weight:600;padding:5px 12px;border-radius:5px;
  cursor:pointer;border:none;background:transparent;color:var(--text3);
  transition:all .15s;font-family:var(--sans)}
.viz-tab.active{background:var(--accent);color:#fff}
.viz-tab:hover:not(.active){color:var(--text)}


/* ── Weekly report ── */
.wk-hero{display:grid;grid-template-columns:2fr 1fr;gap:16px;margin-bottom:28px}
@media (max-width:800px){.wk-hero{grid-template-columns:1fr}}
.wk-tile{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:22px 24px}
.wk-tile.big{background:linear-gradient(135deg,rgba(124,116,255,.14),rgba(124,116,255,.03));border-color:rgba(124,116,255,.35)}
.wk-tile-label{font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#8b949e}
.wk-tile-value{font-size:44px;font-weight:700;color:#e6edf3;line-height:1.1;margin:8px 0 4px;font-variant-numeric:tabular-nums}
.wk-tile.big .wk-tile-value{font-size:56px}
.wk-tile-sub{font-size:12px;color:#8b949e}
.wk-trend{display:inline-block;margin-top:12px;font-size:12px;font-weight:600;color:#c9d1d9;background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:6px;padding:4px 9px}
.wk-trend.muted{color:#8b949e;font-weight:500}
.wk-bar-row{display:grid;grid-template-columns:minmax(140px,220px) 1fr 64px;align-items:center;gap:14px;padding:7px 0}
.wk-bar-lbl{font-size:13px;color:#e6edf3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wk-bar-track{height:10px;background:rgba(255,255,255,.04);border-radius:5px;overflow:hidden}
.wk-bar{height:100%;background:#7c74ff;border-radius:5px}
.wk-bar-val{font-size:13px;color:#e6edf3;text-align:right;font-family:var(--mono)}
.wk-note{font-size:12px;color:#8b949e;line-height:1.6;background:var(--surface);border:1px dashed var(--border2);border-radius:var(--radius);padding:14px 18px}
.wk-note a{color:#a49dff}
.wk-msg{border-radius:8px;padding:10px 16px;font-size:13px;margin-bottom:16px}
.wk-msg.ok{background:rgba(61,214,140,.08);border:1px solid rgba(61,214,140,.25);color:#3dd68c}
.wk-msg.err{background:rgba(255,92,92,.08);border:1px solid rgba(255,92,92,.25);color:#ff9090}

/* ── Time range bar ── */
.range-bar{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:18px}
.range-btn{font-size:12px;font-weight:600;padding:6px 13px;border-radius:7px;
  border:1px solid var(--border);background:var(--surface);color:var(--text3);
  text-decoration:none;transition:all .15s;font-family:var(--sans)}
.range-btn:hover{border-color:rgba(108,99,255,.5);color:var(--text)}
.range-btn.active{background:var(--accent);border-color:var(--accent);color:#fff}

/* ── Alert filter bar ── */
.filter-bar{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:14px}
.filter-bar select, .filter-bar input[type=text]{background:#0d1117;color:#e6edf3;
  border:1px solid #2a3450;border-radius:7px;padding:7px 10px;font-size:12px;
  font-family:var(--sans);outline:none}
.filter-bar input[type=text]{font-family:var(--mono);min-width:160px}
.filter-chip{display:inline-flex;align-items:center;gap:6px;font-size:12px;
  background:rgba(108,99,255,.12);border:1px solid rgba(108,99,255,.3);color:var(--accent);
  border-radius:7px;padding:5px 10px}
.filter-chip a{color:var(--text3);text-decoration:none;font-weight:700}

/* ── Section divider ── */
.section-sub{font-size:12px;color:var(--text3);margin-top:2px;font-weight:400}

/* ── Metric big cards ── */
.metric-tabs{display:flex;gap:0;border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;margin-bottom:20px}
.metric-tab{flex:1;padding:16px 20px;cursor:pointer;border:none;background:var(--surface);color:var(--text2);
  text-align:left;font-family:var(--sans);transition:background .15s;border-right:1px solid var(--border)}
.metric-tab:last-child{border-right:none}
.metric-tab.active{background:var(--surface2);border-bottom:2px solid var(--accent)}
.metric-tab .mt-label{font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px}
.metric-tab .mt-value{font-size:22px;font-weight:700;font-family:var(--mono);color:var(--text)}
.metric-tab.active .mt-value{color:var(--accent)}
.metric-tab .mt-delta{font-size:11px;color:var(--success);margin-top:2px;font-family:var(--mono)}

/* ── Blocklist suggestion cards ── */
.bl-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;margin-bottom:20px}
.bl-card{background:linear-gradient(135deg,var(--surface2),var(--surface3));
  border:1px solid var(--border);border-radius:var(--radius);padding:20px;position:relative;overflow:hidden}
.bl-card::before{content:'';position:absolute;inset:0;
  background:radial-gradient(circle at top right,rgba(108,99,255,.08),transparent 60%)}
.bl-card-ico{font-size:28px;margin-bottom:10px}
.bl-card-name{font-size:14px;font-weight:700;margin-bottom:4px}
.bl-card-desc{font-size:11px;color:var(--text3);line-height:1.5;margin-bottom:12px}
.bl-card-meta{display:flex;justify-content:space-between;font-size:11px;color:var(--text3);font-family:var(--mono)}

/* ── Responsive ── */
@media(max-width:900px){.sidebar{display:none}}

form{display:inline}
.no-data{text-align:center;padding:40px;color:var(--text3);font-family:var(--mono);font-size:12px}
/* CAPI connectivity dot */
.capi-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-left:8px;vertical-align:middle;cursor:help}
.capi-dot.on {background:var(--success);box-shadow:0 0 5px var(--success)}
.capi-dot.off{background:var(--text3)}
/* Override Webmin's body background inside our shell */
body { background: var(--bg) !important; }
</style>
<div class="shell">
HTML


# ── Sidebar ───────────────────────────────────────────────────────────────────
my $cs_dot = $cs_status eq 'active' ? 'on' : ($cs_status eq 'inactive' ? 'off' : 'unk');
my $cb_dot = $cb_status eq 'active' ? 'on' : ($cb_status eq 'inactive' ? 'off' : 'unk');

print <<HTML;
<!-- Sidebar -->
<nav class="sidebar">
  <div class="sb-brand">
    <div class="logo">🛡️</div>
    <div><h2>CrowdSec</h2><p>SECURITY ENGINE</p></div>
  </div>
  @{[$exclude_test ? '<div style="margin:8px 12px 4px;background:rgba(108,99,255,0.12);border:1px solid rgba(108,99,255,0.3);border-radius:7px;padding:5px 10px;font-size:11px;color:#a99cff">&#x25CF; Test IPs filtered</div>' : '']}
  <div class="sb-section">
    <div class="sb-label">Monitor</div>
    <a class="sb-item @{[$tab eq 'engines'   ? 'active' : '']}" href="index.cgi?tab=engines$qs_filter">
      <span class="ico">⚙️</span> Engines
      <span class="badge">@{[scalar @$engines]}</span>
    </a>
    <a class="sb-item @{[$tab eq 'alerts'    ? 'active' : '']}" href="index.cgi?tab=alerts$qs_filter">
      <span class="ico">🔔</span> Alerts
      <span class="badge">$alert_cnt</span>
    </a>
    <a class="sb-item @{[$tab eq 'decisions' ? 'active' : '']}" href="index.cgi?tab=decisions$qs_filter">
      <span class="ico">🚫</span> Decisions
      <span class="badge">$dec_cnt</span>
    </a>
    <a class="sb-item @{[$tab eq 'metrics'   ? 'active' : '']}" href="index.cgi?tab=metrics$qs_filter">
      <span class="ico">📊</span> Remediation Metrics
    </a>
    <a class="sb-item @{[$tab eq 'weekly'    ? 'active' : '']}" href="index.cgi?tab=weekly$qs_filter">
      <span class="ico">🗓️</span> Weekly Report
    </a>
  </div>
  <div class="sb-section">
    <div class="sb-label">Manage</div>
    <a class="sb-item @{[$tab eq 'bouncers' || $tab eq 'services' ? 'active' : '']}" href="index.cgi?tab=bouncers$qs_filter">
      <span class="ico">🔧</span> Services &amp; Bouncers
      <span class="badge">@{[scalar @$bouncers]}</span>
    </a>
    <a class="sb-item @{[$tab eq 'hub'       ? 'active' : '']}" href="index.cgi?tab=hub$qs_filter">
      <span class="ico">📦</span> Hub
    </a>
    <a class="sb-item @{[$tab eq 'whitelist' ? 'active' : '']}" href="index.cgi?tab=whitelist$qs_filter">
      <span class="ico">✅</span> Whitelist
    </a>
  </div>
  <div class="sb-svc">
    <div class="svc-row">
      <span class="svc-name">crowdsec</span>
      <span><span class="dot $cs_dot"></span>@{[uc($cs_status)]}</span>
    </div>
    <div class="svc-row">
      <span class="svc-name">fw-bouncer</span>
      <span><span class="dot $cb_dot"></span>@{[uc($cb_status)]}</span>
    </div>
  </div>
</nav>
HTML


# ── Main content area ─────────────────────────────────────────────────────────
print '<div class="main">';

# ── Helper: time-range button row (Alerts + Remediation Metrics) ─────────────
sub range_bar {
    my ($for_tab) = @_;
    my $html = '';
    for my $s ('1h','24h','3d','7d','15d','30d','all') {
        my $active = ($s eq $since) ? ' active' : '';
        my $url    = "index.cgi?tab=$for_tab&exclude_test=" . ($exclude_test ? 1 : 0) . "&since=$s";
        $html .= qq(<a href="$url" class="range-btn$active">$SINCE_LABELS{$s}</a>);
    }
    return qq(<div class="range-bar">$html</div>);
}

# ── Helper: consistent topbar with filter toggle ──────────────────────────────
sub render_topbar {
    my ($icon, $title, $subtitle, $refresh_tab) = @_;
    my $toggle_url  = "index.cgi?tab=$refresh_tab&exclude_test=" . ($exclude_test ? 0 : 1) . "&since=$since";
    my $refresh_url = "index.cgi?tab=$refresh_tab" . ($exclude_test ? '&exclude_test=1' : '') . "&since=$since";
    my $active_cls  = $exclude_test ? 'active' : '';
    my $sub_html    = $subtitle ? qq( <span style="font-size:13px;font-weight:400;color:#6e7681">· $subtitle</span>) : '';
    my $badge_html  = '';
    my $ranges_tip  = @test_ranges ? join(', ', @test_ranges) : 'none configured';
    if ($exclude_test && $filtered_count > 0) {
        $badge_html = qq( <span class="filter-badge">⚠ $filtered_count test alerts excluded</span>);
    } elsif ($exclude_test && @test_ranges == 0) {
        $badge_html = qq( <span class="filter-badge" style="background:rgba(255,92,92,.1);color:#ff9090;border-color:rgba(255,92,92,.25)">⚠ No ranges configured</span>);
    }
    return <<HTML;
<div class="topbar">
  <div class="page-title"><span class="ico">$icon</span> $title$sub_html$badge_html</div>
  <div class="topbar-right">
    <a href="$toggle_url" class="test-filter $active_cls" title="Ranges: $ranges_tip">
      <span class="tf-dot"></span>Exclude test IPs
    </a>
    <a href="$refresh_url" class="btn btn-ghost btn-sm">↺ Refresh</a>
  </div>
</div>
HTML
}

# ─────────────────────────────────────────────────────────────────────────────
# TAB: ENGINES
# ─────────────────────────────────────────────────────────────────────────────
if ($tab eq 'engines') {

    print render_topbar("⚙️", "Engines", "", "engines");

    print '<div class="content">';

    # ── Health status ────────────────────────────────────────────────────────
    my $hub_updates = get_hub_updates_count();
    my @checks = (
        { label => 'CrowdSec engine running',        ok => ($cs_status eq 'active') },
        { label => 'Firewall bouncer running',        ok => ($cb_status eq 'active') },
        { label => 'No recent engine errors',          ok => !$cs_err },
        { label => 'No recent bouncer errors',         ok => !$cb_err },
        { label => 'At least one security engine registered', ok => (scalar(@$engines) > 0) },
        { label => 'At least one bouncer registered',  ok => (scalar(@$bouncers) > 0) },
        { label => 'Hub items up to date',             ok => ($hub_updates == 0),
          note => $hub_updates ? "$hub_updates update(s) available" : '' },
    );
    my $fail_cnt = scalar grep { !$_->{ok} } @checks;
    my ($hs_color, $hs_bg, $hs_border, $hs_icon, $hs_text) = $fail_cnt == 0
        ? ('#3dd68c', 'rgba(61,214,140,.08)',  'rgba(61,214,140,.3)',  '✓', 'All systems healthy')
        : ('#ff9090', 'rgba(255,92,92,.08)',   'rgba(255,92,92,.3)',   '⚠', "$fail_cnt issue" . ($fail_cnt>1?'s':'') . ' need attention');

    print qq(<div class="card" style="margin-bottom:20px;border-color:$hs_border">
      <div class="card-header">
        <div class="card-title">🩺 System Health</div>
        <span style="font-size:12px;font-weight:700;color:$hs_color;background:$hs_bg;border:1px solid $hs_border;border-radius:7px;padding:4px 10px">$hs_icon $hs_text</span>
      </div>
      <div class="card-body" style="padding:14px 20px">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:8px 24px">);
    for my $c (@checks) {
        my $col = $c->{ok} ? '#3dd68c' : '#ff9090';
        my $ico = $c->{ok} ? '✓' : '✕';
        my $lbl = html_escape($c->{label});
        my $note = $c->{note} ? qq( <span style="color:#6e7681;font-size:11px">($c->{note})</span>) : '';
        print qq(<div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#c9d1d9">
          <span style="color:$col;font-weight:700">$ico</span>$lbl$note
        </div>);
    }
    print '</div></div></div>';

    # Stat row — use local service status for "active" count, not CAPI isOnline
    my $online  = ($cs_status eq 'active') ? scalar(@$engines) : 0;
    my $sc_cnt  = $hub->{scenarios}   || 0;
    my $par_cnt = $hub->{parsers}     || 0;
    my $bl_cnt  = $hub->{collections} || 0;

    print <<HTML;
  <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:24px">

    <a href="index.cgi?tab=alerts$qs_filter" style="text-decoration:none">
    <div style="background:var(--surface);border:1px solid var(--border);
      border-radius:10px;padding:18px 16px;cursor:pointer;transition:all .15s"
      onmouseover="this.style.borderColor='rgba(108,99,255,.5)';this.style.background='rgba(108,99,255,0.06)'"
      onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--surface)'">
      <div style="font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">🔔 Alerts · $since</div>
      <div style="font-size:32px;font-weight:700;font-family:var(--mono);color:#e6edf3;line-height:1">$alert_cnt</div>
      <div style="font-size:11px;color:#6e7681;margin-top:6px">All local detections</div>
    </div></a>

    <a href="index.cgi?tab=engines$qs_filter" style="text-decoration:none">
    <div style="background:var(--surface);border:1px solid var(--border);
      border-radius:10px;padding:18px 16px;cursor:pointer;transition:all .15s"
      onmouseover="this.style.borderColor='rgba(108,99,255,.5)';this.style.background='rgba(108,99,255,0.06)'"
      onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--surface)'">
      <div style="font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">⚙️ Engines</div>
      <div style="font-size:32px;font-weight:700;font-family:var(--mono);color:#e6edf3;line-height:1">@{[scalar @$engines]}</div>
      <div style="font-size:11px;color:#6e7681;margin-top:6px">$online active</div>
    </div></a>

    <a href="index.cgi?tab=decisions$qs_filter" style="text-decoration:none">
    <div style="background:var(--surface);border:1px solid var(--border);
      border-radius:10px;padding:18px 16px;cursor:pointer;transition:all .15s"
      onmouseover="this.style.borderColor='rgba(108,99,255,.5)';this.style.background='rgba(108,99,255,0.06)'"
      onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--surface)'">
      <div style="font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">🚫 Decisions</div>
      <div style="font-size:32px;font-weight:700;font-family:var(--mono);color:#e6edf3;line-height:1">$dec_cnt</div>
      <div style="font-size:11px;color:#6e7681;margin-top:6px">Active bans</div>
    </div></a>

    <a href="index.cgi?tab=hub$qs_filter" style="text-decoration:none">
    <div style="background:var(--surface);border:1px solid var(--border);
      border-radius:10px;padding:18px 16px;cursor:pointer;transition:all .15s"
      onmouseover="this.style.borderColor='rgba(108,99,255,.5)';this.style.background='rgba(108,99,255,0.06)'"
      onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--surface)'">
      <div style="font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">🎯 Scenarios</div>
      <div style="font-size:32px;font-weight:700;font-family:var(--mono);color:#e6edf3;line-height:1">$sc_cnt</div>
      <div style="font-size:11px;color:#6e7681;margin-top:6px">Installed</div>
    </div></a>

    <a href="index.cgi?tab=bouncers$qs_filter" style="text-decoration:none">
    <div style="background:var(--surface);border:1px solid var(--border);
      border-radius:10px;padding:18px 16px;cursor:pointer;transition:all .15s"
      onmouseover="this.style.borderColor='rgba(108,99,255,.5)';this.style.background='rgba(108,99,255,0.06)'"
      onmouseout="this.style.borderColor='var(--border)';this.style.background='var(--surface)'">
      <div style="font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-bottom:8px">🔥 Bouncers</div>
      <div style="font-size:32px;font-weight:700;font-family:var(--mono);color:#e6edf3;line-height:1">@{[scalar @$bouncers]}</div>
      <div style="font-size:11px;color:#6e7681;margin-top:6px">Remediation</div>
    </div></a>

  </div>
HTML

    # Engine cards
    if (@$engines) {
        for my $eng (@$engines) {
            # Name: cscli machines list gives a short 'name' field (e.g. "web01")
            # and a long machineId. Use short name if it exists and is short,
            # otherwise take last 4 chars with "..." prefix like the console does.
            my $short_name = $eng->{name} || '';
            my $full_mid   = $eng->{machine_id} || '';
            my $display_name;
            if ($short_name && length($short_name) <= 20 && $short_name ne $full_mid) {
                # cscli gives a readable short name — use it
                $display_name = $short_name;
            } elsif ($full_mid) {
                # Long machine ID — truncate like the console: "...Xkkp"
                $display_name = '...' . substr($full_mid, -4);
            } else {
                $display_name = 'unknown';
            }
            my $name  = html_escape($display_name);
            my $mid   = html_escape($full_mid || '-');
            my $ver   = html_escape($eng->{version} || '');
            my $ip    = html_escape($eng->{ip_address} || '-');

            # Human-readable "last seen" — convert ISO8601 to relative time
            my $lu_raw = $eng->{last_update} || '';
            my $lu_display;
            if ($lu_raw =~ /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/) {
                # Parse timestamp and compute age
                eval { require POSIX; };
                my ($yr,$mo,$dy,$hr,$mn,$sc) = ($1,$2,$3,$4,$5,$6);
                # Build epoch via string (avoids timezone issues — treat as UTC)
                my $ts_epoch = eval {
                    require Time::Piece;
                    Time::Piece->strptime($lu_raw =~ s/\.\d+Z?$//r . 'Z', '%Y-%m-%dT%H:%M:%SZ')->epoch;
                };
                if ($ts_epoch) {
                    my $age = time() - $ts_epoch;
                    if    ($age < 60)        { $lu_display = 'just now'; }
                    elsif ($age < 3600)      { $lu_display = int($age/60)   . ' min ago'; }
                    elsif ($age < 86400)     { $lu_display = int($age/3600) . ' hours ago'; }
                    else                     { $lu_display = int($age/86400). ' days ago'; }
                } else {
                    # Fallback: reformat ISO string nicely
                    $lu_display = "$dy/$mo/$yr $hr:$mn";
                }
            } else {
                $lu_display = $lu_raw || '-';
            }
            my $lu = html_escape($lu_display);

            # Status badge: use systemctl for ACTIVE/INACTIVE
            # Show CAPI connectivity as a separate small indicator
            my $svc_running = ($cs_status eq 'active');
            my $online_cls  = $svc_running ? 'tag active' : 'tag inactive';
            my $online_lbl  = $svc_running ? 'ACTIVE'    : 'INACTIVE';
            my $capi_cls    = $eng->{is_online} ? 'capi-dot on' : 'capi-dot off';
            my $capi_tip    = $eng->{is_online} ? 'CAPI: connected' : 'CAPI: offline (normal for community)';
            print <<HTML;
  <div class="card" style="margin-bottom:16px">
    <div class="card-header">
      <div class="card-title">🖥️ $name
        <span class="$online_cls">$online_lbl</span>
        <span class="$capi_cls" title="$capi_tip"></span>
      </div>
      <span style="font-family:var(--mono);font-size:11px;color:var(--text3)">$ver</span>
    </div>
    <div class="card-body">
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:16px">
        <div style="grid-column:1/-1">
          <div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px">Machine ID</div>
          <div style="font-family:var(--mono);font-size:11px;color:var(--text2);word-break:break-all;line-height:1.5">$mid</div>
        </div>
        <div><div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px">IP Address</div>
          <div style="font-family:var(--mono);font-size:12px">$ip</div></div>
        <div><div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px">Last Seen</div>
          <div style="font-size:12px;color:var(--text2)">$lu</div></div>
        <div><div style="font-size:10px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:3px">Alerts · $since</div>
          <div style="font-size:24px;font-weight:700;font-family:var(--mono);color:var(--accent)">$alert_cnt</div></div>
      </div>
      <div style="display:flex;gap:8px">
        <div style="background:rgba(108,99,255,0.12);border:1px solid rgba(108,99,255,0.25);border-radius:8px;padding:12px 14px;flex:1;text-align:center">
          <div style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--accent)">$sc_cnt</div>
          <div style="font-size:11px;color:var(--text2);margin-top:4px;font-weight:500">Scenarios</div></div>
        <div style="background:rgba(245,166,35,0.1);border:1px solid rgba(245,166,35,0.25);border-radius:8px;padding:12px 14px;flex:1;text-align:center">
          <div style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--accent2)">@{[scalar @$bouncers]}</div>
          <div style="font-size:11px;color:var(--text2);margin-top:4px;font-weight:500">Bouncers</div></div>
        <div style="background:rgba(78,205,196,0.1);border:1px solid rgba(78,205,196,0.25);border-radius:8px;padding:12px 14px;flex:1;text-align:center">
          <div style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--accent3)">$bl_cnt</div>
          <div style="font-size:11px;color:var(--text2);margin-top:4px;font-weight:500">Collections</div></div>
      </div>
    </div>
  </div>
HTML
        }
    } else {
        print '<div class="no-data">No engines found — is CrowdSec running?</div>';
    }
    print '</div>'; # /content
}


# ─────────────────────────────────────────────────────────────────────────────
# TAB: ALERTS
# ─────────────────────────────────────────────────────────────────────────────
elsif ($tab eq 'alerts') {

    # Build ranked list HTML helper — max=0 means show all
    sub ranked_html {
        my ($items, $max) = @_;
        $max //= 3;
        my $html = '<ul class="ranked-list">';
        my $r = 1;
        for my $it (@$items) {
            next unless defined $it->{label} && $it->{label} ne '' && $it->{label} ne '-';
            my $n = $r <= 3 ? $r : 4;  # only 3 badge styles, rest use r4 = plain
            my $cls = "r$n";
            my $lbl = html_escape($it->{label});
            $html .= qq(<li class="ranked-item">
              <span class="rank-badge $cls">$r</span>
              <span class="ranked-label" title="$lbl">$lbl</span>
              <span class="ranked-count">x $it->{count}</span>
            </li>);
            last if $max > 0 && $r++ >= $max;
            $r++ if $max == 0;
        }
        $html .= '</ul>';
        return $html;
    }

    my $ip_list  = ranked_html($top_ips);
    my $as_list  = ranked_html($top_as);
    my $eng_list = ranked_html($top_eng);
    my $sc_list  = ranked_html($top_sc);

    # Expanded lists — all entries
    my $ip_list_exp  = ranked_html($exp_ips,  0);
    my $as_list_exp  = ranked_html($exp_as,   0);
    my $eng_list_exp = ranked_html($exp_eng,  0);
    my $sc_list_exp  = ranked_html($exp_sc,   0);

print render_topbar("🔔", "Alerts", $since_label, "alerts");
print '<div class="content">';

    print range_bar('alerts');

    # ── Alert log filter (Source IP / Source AS / Scenario / Security Engine) ─
    my %FILTER_FIELDS = (
        src_ip => 'Source IP', src_as => 'Source AS',
        scenario => 'Scenario', engine => 'Security Engine',
    );
    my $ffield = $in{'ffield'} || '';
    my $fvalue = $in{'fvalue'} || '';
    $ffield = '' unless exists $FILTER_FIELDS{$ffield};

    my $field_opts = '';
    for my $k (sort keys %FILTER_FIELDS) {
        my $sel = ($k eq $ffield) ? ' selected' : '';
        $field_opts .= qq(<option value="$k"$sel>$FILTER_FIELDS{$k}</option>);
    }
    my $fvalue_esc = html_escape($fvalue);
    my $base_qs = "tab=alerts&exclude_test=" . ($exclude_test?1:0) . "&since=$since";
    print <<HTML;
  <div class="filter-bar">
    <form method="get" action="index.cgi" style="display:flex;gap:8px;align-items:center">
      <input type="hidden" name="tab" value="alerts">
      <input type="hidden" name="exclude_test" value="@{[$exclude_test?1:0]}">
      <input type="hidden" name="since" value="$since">
      <select name="ffield"><option value="">+ Filter by…</option>$field_opts</select>
      <input type="text" name="fvalue" value="$fvalue_esc" placeholder="value contains…">
      <button type="submit" class="btn btn-ghost btn-sm">Apply</button>
    </form>
HTML
    if ($ffield && $fvalue ne '') {
        my $lbl = html_escape($FILTER_FIELDS{$ffield});
        print qq(<span class="filter-chip">$lbl: "$fvalue_esc" <a href="index.cgi?$base_qs">✕</a></span>);
    }
    print '</div>';

    # Apply filter to the alert log (visualizer numbers stay unfiltered, showing the full window)
    my $alerts_log = $alerts;
    if ($ffield && $fvalue ne '') {
        my $fv = lc $fvalue;
        $alerts_log = [ grep {
            my $val = lc(_alert_field($_, $ffield) // '');
            index($val, $fv) >= 0;
        } @$alerts ];
    }

    # Quota-style banner
    print <<HTML;
  <div class="stat-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px">
    <div class="stat-card accent"><div class="label">Total Alerts · $since <span style="font-size:9px;opacity:.6">LOCAL</span></div>
      <div class="value">$alert_cnt</div>
      <div class="sub" style="font-size:10px">All local detections · app.crowdsec.net shows fewer (noise cancelling + CAPI quota)</div></div>
    <div class="stat-card"><div class="label">Unique IPs</div>
      <div class="value">$uniq_ip_cnt</div></div>
    <div class="stat-card"><div class="label">Scenarios triggered</div>
      <div class="value">@{[scalar keys %$sc_counts]}</div></div>
  </div>
HTML

    # Visualizer
    print <<HTML;
  <div class="card">
    <div class="card-header">
      <div class="card-title">📡 Visualizer</div>
      <div class="viz-tabs">
        <button class="viz-tab" onclick="setViz('none',this)">⊘ None</button>
        <button class="viz-tab active" onclick="setViz('summary',this)">≡ Summary</button>
        <button class="viz-tab" onclick="setViz('expanded',this)">⤢ Expanded</button>
      </div>
    </div>
    <div class="card-body" id="viz-body">
      <div class="viz-grid">
        <div class="viz-card">
          <div class="viz-card-title">Source IP <span style="font-weight:400;color:#6e7681;font-size:10px">$ip_total hits · $ip_uniq unique</span></div>
          <div class="chart-wrap">$svg_ip</div>
          <div class="viz-summary">$ip_list</div>
          <div class="viz-expanded" style="display:none">$ip_list_exp</div>
        </div>
        <div class="viz-card" style="position:relative">
          <div class="viz-card-title">Source ASs <span style="font-weight:400;color:#6e7681;font-size:10px">$as_total hits · $as_uniq unique</span></div>
          <div class="chart-wrap">$svg_as</div>
          <div class="viz-summary">$as_list</div>
          <div class="viz-expanded" style="display:none">$as_list_exp</div>
          <div class="tooltip-box" id="eng-tip">
            <div class="tb-row"><span class="tb-label">Security Engine name: </span><span class="tb-val">$eng_name</span></div>
            <div class="tb-row"><span class="tb-label">Security Engine ID: </span><span class="tb-val" style="word-break:break-all">$eng_id</span></div>
          </div>
        </div>
        <div class="viz-card">
          <div class="viz-card-title">Targeted Security Engines <span style="font-weight:400;color:#6e7681;font-size:10px">$eng_total hits</span></div>
          <div class="chart-wrap">$svg_eng</div>
          <div class="viz-summary">$eng_list</div>
          <div class="viz-expanded" style="display:none">$eng_list_exp</div>
        </div>
        <div class="viz-card">
          <div class="viz-card-title">Scenarios <span style="font-weight:400;color:#6e7681;font-size:10px">$sc_total hits · $sc_uniq triggered</span></div>
          <div class="chart-wrap">$svg_sc</div>
          <div class="viz-summary">$sc_list</div>
          <div class="viz-expanded" style="display:none">$sc_list_exp</div>
        </div>
      </div>
    </div>
  </div>
HTML

    # Alert table
    print <<HTML;
  <div class="card">
    <div class="card-header">
      <div class="card-title">📋 Alert Log</div>
      <span style="font-size:11px;color:var(--text3)">Showing @{[scalar @$alerts_log]} results</span>
    </div>
    <div class="card-body no-pad">
HTML
    if (@$alerts_log) {
        print '<table class="tbl"><thead><tr>
          <th>When</th><th>Scenario</th><th>Source</th><th>Target</th><th>Decisions</th></tr></thead><tbody>';
        my $shown = 0;
        for my $a (@$alerts_log) {
            last if $shown++ >= 100;
            my $when    = html_escape($a->{start_at} // '-');
            my $sc      = html_escape($a->{scenario}  // '-');
            my $src_ip  = html_escape($a->{source}{ip} // 'Scope: range');
            my $src_as  = html_escape($a->{source}{as_name} // $a->{source}{as_number} // '');
            my $src_cn  = html_escape($a->{source}{cn} // '');
            my $src_sub = join(' ', grep {$_} ($src_as, $src_cn));
            my $target  = html_escape($a->{machine_id} // $a->{machineId} // '-');
            # Truncate long machine IDs
            my $target_short = length($target) > 20 ? '...'.substr($target,-4) : $target;
            my $ndec    = scalar @{$a->{decisions} // []};
            print <<HTML;
<tr>
  <td class="mono" style="white-space:nowrap;font-size:11px">$when</td>
  <td><span class="tag scenario">$sc</span></td>
  <td class="mono"><span style="font-weight:600">$src_ip</span><br><span style="color:var(--text3);font-size:10px">$src_sub</span></td>
  <td class="mono" style="font-size:11px">$target_short</td>
  <td><span class="tag ban">$ndec ban</span></td>
</tr>
HTML
        }
        print '</tbody></table>';
    } else {
        print qq(<div class="no-data">✓ No alerts — $since_label</div>);
    }
    print '</div></div>'; # card
    print '</div>'; # content
}


# ─────────────────────────────────────────────────────────────────────────────
# TAB: DECISIONS
# ─────────────────────────────────────────────────────────────────────────────
elsif ($tab eq 'decisions') {

    # Count by origin so we can explain what each group means
    my ($local_cnt, $capi_cnt, $cscli_cnt) = (0, 0, 0);
    for my $d (@$decisions) {
        my $orig = lc($d->{origin} // $d->{Origin} // '');
        if    ($orig eq 'crowdsec') { $local_cnt++; }
        elsif ($orig eq 'capi')     { $capi_cnt++;  }
        elsif ($orig eq 'cscli')    { $cscli_cnt++; }
    }

    print render_topbar("🚫", "Decisions", "", "decisions");
    print '<div class="content">';

    # Stat cards
    print <<HTML;
  <div class="stat-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
    <div class="stat-card accent"><div class="label">Total Active</div>
      <div class="value">$dec_cnt</div><div class="sub">IPs currently banned</div></div>
    <div class="stat-card"><div class="label">CAPI Community</div>
      <div class="value" style="color:#a99cff">$capi_cnt</div>
      <div class="sub">Global blocklist</div></div>
    <div class="stat-card"><div class="label">Local Engine</div>
      <div class="value" style="color:#3dd68c">$local_cnt</div>
      <div class="sub">Your detections</div></div>
    <div class="stat-card"><div class="label">Manual (cscli)</div>
      <div class="value">$cscli_cnt</div>
      <div class="sub">Added by hand</div></div>
  </div>
HTML

    # Decisions table
    print <<HTML;
  <div class="card">
    <div class="card-header">
      <div class="card-title">Active Ban List</div>
      <span style="font-size:11px;color:#6e7681">$dec_cnt decisions · firewall rules currently enforced</span>
    </div>
    <div class="card-body no-pad">
HTML
    if (@$decisions) {
        print '<table class="tbl"><thead><tr>
          <th>Banned IP / Range</th><th>Origin</th><th>Reason / Scenario</th><th>Expires in</th><th></th>
        </tr></thead><tbody>';

        for my $d (@$decisions) {
            # Fields now come pre-flattened from get_decisions()
            my $ip       = html_escape($d->{value}    // '-');
            my $scope    = lc($d->{scope}   // 'ip');
            my $origin   = $d->{origin}     // '-';
            my $scenario = html_escape($d->{scenario} // '-');
            my $duration = html_escape($d->{duration} // '-');
            my $id       = html_escape($d->{id}       // '');
            my $asn      = html_escape($d->{src_asn}  // '');
            my $cn       = html_escape($d->{src_cn}   // '');
            my $sim      = $d->{simulated}  ? 1 : 0;

            # Origin label + colour
            my ($orig_label, $orig_style);
            if    (lc($origin) eq 'capi')     { $orig_label='CAPI';   $orig_style='color:#a99cff'; }
            elsif (lc($origin) eq 'crowdsec') { $orig_label='Local';  $orig_style='color:#3dd68c'; }
            elsif (lc($origin) eq 'cscli')    { $orig_label='Manual'; $orig_style='color:#f5a623'; }
            else                              { $orig_label=html_escape($origin); $orig_style='color:#8b949e'; }

            # Scope badge for ranges
            my $scope_badge = ($scope eq 'range' || $ip =~ /\/\d+$/)
                ? ' <span style="font-size:9px;background:rgba(108,99,255,.15);color:#a99cff;padding:1px 5px;border-radius:3px;margin-left:4px">range</span>'
                : '';

            # Simulated badge
            my $sim_badge = $sim
                ? ' <span style="font-size:9px;background:rgba(245,166,35,.15);color:#f5a623;padding:1px 5px;border-radius:3px;margin-left:4px">simulated</span>'
                : '';

            # Duration colour — amber when expiring soon
            my $dur_style = 'color:#8b949e';
            if ($duration =~ /^(\d+)h/ && $1 <= 1) { $dur_style = 'color:#f5a623'; }
            if ($duration =~ /^(\d+)m/)             { $dur_style = 'color:#f5a623'; }

            # ASN/country subtitle under IP
            my $ip_sub = '';
            $ip_sub = join(' ', grep {$_} ($asn, $cn));
            $ip_sub = $ip_sub ? qq(<br><span style="font-size:10px;color:#6e7681;font-weight:400">$ip_sub</span>) : '';

            print <<HTML;
<tr>
  <td class="mono" style="font-weight:600;line-height:1.4">$ip$scope_badge$sim_badge$ip_sub</td>
  <td style="font-size:12px;font-weight:600;$orig_style">$orig_label</td>
  <td style="font-size:11px;color:#8b949e;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="$scenario">$scenario</td>
  <td class="mono" style="font-size:11px;$dur_style">$duration</td>
  <td>
    <form method="post" action="action.cgi" style="display:inline">
      <input type="hidden" name="action" value="delete_decision">
      <input type="hidden" name="id" value="$id">
      <button class="btn btn-danger btn-sm" type="submit"
        onclick="return confirm('Unban $ip?')">🗑 Unban</button>
    </form>
  </td>
</tr>
HTML
        }
        print '</tbody></table>';
    } else {
        print '<div class="no-data">✓ No active decisions — no IPs are currently banned by your engine</div>';
    }
    print '</div></div>'; # card
    print '</div>'; # content
}

# TAB: REMEDIATION METRICS
# ─────────────────────────────────────────────────────────────────────────────
elsif ($tab eq 'metrics') {
    my $bytes_dropped    = fmt_bytes($metrics->{bytes}   || 0);
    my $packets_dropped  = fmt_num($metrics->{packets}   || 0) . ' packets';
    my $active_decisions = $metrics->{active_decisions}  || 0;

    # Per-origin breakdown (CAPI, crowdsec engine, cscli)
    my $capi_bytes    = fmt_bytes($metrics_by_origin->{CAPI}{bytes}      || 0);
    my $capi_packets  = $metrics_by_origin->{CAPI}{packets}              || 0;
    my $capi_dec      = $metrics_by_origin->{CAPI}{decisions}            || 0;
    my $eng_bytes     = fmt_bytes($metrics_by_origin->{crowdsec}{bytes}  || 0);
    my $eng_packets   = $metrics_by_origin->{crowdsec}{packets}          || 0;
    my $eng_dec       = $metrics_by_origin->{crowdsec}{decisions}        || 0;

    # Percentages
    my $total_b = ($metrics->{bytes} || 0);
    my $capi_b_raw = $metrics_by_origin->{CAPI}{bytes}     || 0;
    my $eng_b_raw  = $metrics_by_origin->{crowdsec}{bytes} || 0;
    my $capi_pct = $total_b > 0 ? sprintf("%.1f", $capi_b_raw / $total_b * 100) : '0.0';
    my $eng_pct  = $total_b > 0 ? sprintf("%.1f", $eng_b_raw  / $total_b * 100) : '0.0';

    # ── Per-day alert bucketing — follows the selected time range ────────────
    # 1h/24h still show 2 days (today + yesterday) so the chart is never a
    # single lonely bar; "all" spans from the oldest alert (capped at 90 days).
    my %RANGE_DAYS = ('1h'=>2, '24h'=>2, '3d'=>3, '7d'=>7, '15d'=>15, '30d'=>30);
    my $n_days = $RANGE_DAYS{$since};
    if (!$n_days) {    # all time
        require Time::Local;
        my @now = localtime();
        my $today = Time::Local::timelocal(0,0,12,$now[3],$now[4],$now[5]);
        my $oldest = $today;
        for my $a (@$alerts) {
            if (($a->{start_at} // '') =~ /^(\d{4})-(\d{2})-(\d{2})T/) {
                my $t = eval { Time::Local::timelocal(0,0,12,$3,$2-1,$1) };
                $oldest = $t if $t && $t < $oldest;
            }
        }
        $n_days = int(($today - $oldest) / 86400 + 0.5) + 1;   # calendar days, inclusive
        $n_days = 2  if $n_days < 2;
        $n_days = 90 if $n_days > 90;
    }
    my $alerts_7d = $alerts;   # the page-wide alert set already honours $since

    my @day_labels;
    my %day_sc;
    my %all_sc;
    {
        for my $d (reverse 0..($n_days-1)) {
            my @t = localtime(time() - $d * 86400);
            my $lbl = sprintf("%s %02d", (qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/)[$t[4]], $t[3]);
            push @day_labels, $lbl;
            $day_sc{$lbl} = {};
        }
    }
    for my $a (@$alerts_7d) {
        my $sc  = $a->{scenario} // 'unknown';
        my $ts  = $a->{start_at} // '';
        my ($mo, $dy) = (0, 0);
        if ($ts =~ /\d{4}-(\d{2})-(\d{2})T/) { $mo = $1+0; $dy = $2+0; }
        my $lbl_mo = (qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/)[$mo-1] // 'Jan';
        my $lbl = sprintf("%s %02d", $lbl_mo, $dy);
        if (exists $day_sc{$lbl}) { $day_sc{$lbl}{$sc}++; $all_sc{$sc}++; }
    }
    my @top_sc_names = (sort { $all_sc{$b} <=> $all_sc{$a} } keys %all_sc)[0..9];
    my $sc_total = 0; $sc_total += ($all_sc{$_}||0) for @top_sc_names;

    # Build CSS stacked bar chart (pure HTML, no JS/canvas)
    my $stacked_bar_html = css_stacked_bars(\@day_labels, \@top_sc_names, \%day_sc, \@SC_COLORS, 140);

    # Build traffic bar chart (daily alert counts, split CAPI/engine)
    my $maxV_day = 1;
    my @day_totals = map { my $d=$_; my $s=0; $s+=$_ for values %{$day_sc{$d}}; $s } @day_labels;
    for (@day_totals) { $maxV_day = $_ if $_ > $maxV_day; }
    my $traffic_bar_html = '<div style="height:120px;display:flex;gap:2px;align-items:flex-end;padding:4px 2px 0">';
    for my $i (0..$#day_labels) {
        my $v    = $day_totals[$i] || 0;
        my $pct  = $maxV_day > 0 ? int($v / $maxV_day * 100) : 0;
        my $capH = int($pct * 0.85);
        my $engH = $pct - $capH;
        $traffic_bar_html .= qq(<div style="flex:1;display:flex;flex-direction:column;align-items:center">)
            . qq(<div style="width:80%;display:flex;flex-direction:column;justify-content:flex-end;height:100px">)
            . ($v > 0
                ? qq(<div style="height:${engH}%;background:#f5a623;min-height:2px;border-radius:2px 2px 0 0"></div>)
                . qq(<div style="height:${capH}%;background:#6c63ff;min-height:2px"></div>)
                : '')
            . qq(</div>)
            . qq(<div style="font-size:8px;color:#6e7681;font-family:monospace;margin-top:2px;white-space:nowrap">$day_labels[$i]</div>)
            . qq(</div>);
    }
    $traffic_bar_html .= '</div>';

    # Build table
    my $sc_tbl_html = '';
    my $ci = 0;
    for my $sc (@top_sc_names) {
        next unless $sc;
        my $col   = $SC_COLORS[$ci++ % scalar @SC_COLORS];
        my $cnt   = $all_sc{$sc} || 0;
        my $pct   = $sc_total > 0 ? sprintf("%.1f", $cnt/$sc_total*100) : '0.0';
        my $sc_e  = html_escape($sc);
        my $cnt_f = fmt_num($cnt);
        $sc_tbl_html .= qq(<tr>
          <td><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:$col;margin-right:8px;vertical-align:middle"></span>$sc_e</td>
          <td class="mono" style="text-align:right">$cnt_f</td>
          <td class="mono" style="text-align:right;color:#6e7681">$pct%</td>
        </tr>);
    }
    my $sc_total_fmt  = fmt_num($sc_total);

    # ── Per-day bytes/packets bucketing ───────────────────────────────────────
    # Since cscli metrics doesn't give per-day data, we show a sparkline
    # based on alert frequency as a proxy (packets ~ alerts * avg_packet_size)
    my @day_alerts = map { my $d=$_; my $sum=0; $sum += $_ for values %{$day_sc{$d}}; $sum } @day_labels;

    print <<HTML;
HTML
print render_topbar("📊", "Remediation Metrics", $since_label, "metrics");
print '<div class="content">';
print range_bar('metrics');
print <<HTML;
  <!-- ── Distribution of Malicious Intents ── -->
  <div class="section-title">✨ Distribution of Malicious Intents
    <div class="section-sub">Breakdown of attack typology associated with IPs blocked by security engines</div>
  </div>
  <div class="card" style="margin-bottom:20px">
    <div class="card-body">
      <div style="display:inline-block;border-bottom:2px solid var(--accent);padding-bottom:8px;margin-bottom:16px">
        <div style="font-size:12px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em">Prevented attacks</div>
        <div style="font-size:32px;font-weight:700;font-family:var(--mono)">$sc_total_fmt</div>
      </div>
      <!-- Stacked bar chart - pure CSS, no JS needed -->
      $stacked_bar_html
      <!-- Legend table -->
      <table class="tbl">
        <thead><tr><th>Scenario</th><th style="text-align:right">Count</th><th style="text-align:right">Share</th></tr></thead>
        <tbody>$sc_tbl_html</tbody>
      </table>
    </div>
  </div>

  <!-- ── Malicious Traffic Discarded ── -->
  <div class="section-title">🛡️ Malicious Traffic Discarded
    <div class="section-sub">Discarded traffic based on remediation component metrics · cumulative since the bouncer last started (not affected by the time range)</div>
  </div>
  <div class="card" style="margin-bottom:20px">
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0;border:1px solid var(--border);border-radius:8px;overflow:hidden;margin-bottom:20px">
        <div style="padding:16px 20px;border-right:1px solid var(--border)">
          <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Bytes dropped</div>
          <div style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--accent)">$bytes_dropped</div>
        </div>
        <div style="padding:16px 20px;border-right:1px solid var(--border)">
          <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Packets dropped</div>
          <div style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--accent)">$packets_dropped</div>
        </div>
        <div style="padding:16px 20px">
          <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Active decisions</div>
          <div style="font-size:22px;font-weight:700;font-family:var(--mono);color:var(--accent)">$active_decisions</div>
        </div>
      </div>
      <!-- Traffic bar chart (daily alert proxy) -->
      $traffic_bar_html
      <div style="display:flex;gap:16px;margin-top:8px;font-size:11px">
        <span><span style="display:inline-block;width:10px;height:10px;background:#6c63ff;border-radius:2px;margin-right:4px;vertical-align:middle"></span>Community Blocklist (CAPI)</span>
        <span><span style="display:inline-block;width:10px;height:10px;background:#f5a623;border-radius:2px;margin-right:4px;vertical-align:middle"></span>CrowdSec Security Engine</span>
      </div>
    </div>
  </div>

  <!-- ── Projected Resources Saved ── -->
  <div class="section-title">💾 Projected Resources Saved
    <div class="section-sub">Estimated resource savings from blocklists based on remediation metrics · cumulative since the bouncer last started</div>
  </div>
  <div class="card" style="margin-bottom:20px">
    <div class="card-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;border:1px solid var(--border);border-radius:8px;overflow:hidden;margin-bottom:20px">
        <div style="padding:16px 20px;border-right:1px solid var(--border)">
          <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Outgoing traffic dropped</div>
          <div style="font-size:22px;font-weight:700;font-family:var(--mono)">$bytes_dropped</div>
        </div>
        <div style="padding:16px 20px">
          <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Packets dropped</div>
          <div style="font-size:22px;font-weight:700;font-family:var(--mono)">$packets_dropped</div>
        </div>
      </div>
      <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:14px 16px;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-size:13px;font-weight:600">Community Blocklist (CAPI) <span style="font-size:10px;background:rgba(245,166,35,.15);color:var(--accent2);border:1px solid rgba(245,166,35,.3);padding:1px 6px;border-radius:4px;margin-left:4px">FREE TIER</span></div>
          <div style="font-size:11px;color:var(--text3);margin-top:2px">IP addresses reported by the CrowdSec community worldwide via the Central API · <strong style="color:#e6edf3">$capi_dec</strong> active decisions</div>
        </div>
        <div style="text-align:right;font-family:var(--mono)">
          <div style="font-size:15px;font-weight:700">$capi_bytes</div>
          <div style="font-size:11px;color:var(--text3)">$capi_pct%</div>
        </div>
      </div>
      <div style="background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-size:13px;font-weight:600">CrowdSec Security Engine</div>
          <div style="font-size:11px;color:var(--text3);margin-top:2px">Threats detected and blocked by your own Security Engines · <strong style="color:#e6edf3">$eng_dec</strong> active decisions</div>
        </div>
        <div style="text-align:right;font-family:var(--mono)">
          <div style="font-size:15px;font-weight:700">$eng_bytes</div>
          <div style="font-size:11px;color:var(--text3)">$eng_pct%</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── Blocklists: live data lives on the Weekly Report tab ── -->
  <div class="wk-note" style="margin-bottom:20px">🛡️ Per-blocklist traffic and premium list recommendations are on the
    <a href="index.cgi?tab=weekly$qs_filter">Weekly Report</a> tab.</div>

  <!-- ── Source breakdown ── -->
  <div class="section-title">🌍 Traffic Sources</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
    <div class="card">
      <div class="card-header"><div class="card-title">Top Source IPs</div></div>
      <div class="card-body no-pad">
        <table class="tbl"><thead><tr><th>IP</th><th>ASN</th><th>Country</th><th style="text-align:right">Alerts</th></tr></thead><tbody>
HTML

    my %ip_as;
    for my $a (@$alerts) {
        my $ip = $a->{source}{ip} // next;
        $ip_as{$ip} //= {as => $a->{source}{as_name} // '-', cn => $a->{source}{cn} // '-', count => 0};
        $ip_as{$ip}{count}++;
    }
    for my $ip (sort { $ip_as{$b}{count} <=> $ip_as{$a}{count} } keys %ip_as) {
        my $d = $ip_as{$ip};
        printf '<tr><td class="mono">%s</td><td style="font-size:11px;color:var(--text3)">%s</td><td>%s</td><td class="mono" style="text-align:right">%d</td></tr>',
            html_escape($ip), html_escape($d->{as}), html_escape($d->{cn}), $d->{count};
    }
    print '</tbody></table></div></div>';

    print '<div class="card"><div class="card-header"><div class="card-title">Top ASNs</div></div>
      <div class="card-body no-pad"><table class="tbl"><thead><tr><th>ASN</th><th style="text-align:right">Alerts</th><th style="text-align:right">%</th></tr></thead><tbody>';
    my %as_cnt;
    for my $a (@$alerts) {
        my $as = $a->{source}{as_name} || $a->{source}{as_number} || '-';
        $as_cnt{$as}++;
    }
    for my $as (sort { $as_cnt{$b} <=> $as_cnt{$a} } keys %as_cnt) {
        my $pct = $alert_cnt > 0 ? sprintf("%.1f", $as_cnt{$as}/$alert_cnt*100) : '0.0';
        printf '<tr><td>%s</td><td class="mono" style="text-align:right">%s</td><td class="mono" style="text-align:right;color:var(--text3)">%s%%</td></tr>',
            html_escape($as), fmt_num($as_cnt{$as}), $pct;
    }
    print '</tbody></table></div></div></div>';  # two-col + content
    print '</div>';
} # end metrics tab


# ─────────────────────────────────────────────────────────────────────────────
# TAB: SERVICES (merged with Bouncers)
# ─────────────────────────────────────────────────────────────────────────────
elsif ($tab eq 'bouncers' || $tab eq 'services') {
print render_topbar("🔧", "Services &amp; Bouncers", "", "bouncers");
print '<div class="content">';

    # ── Service control cards ────────────────────────────────────────────────
    print '<div class="section-title" style="margin-bottom:14px">⚙️ Service Control</div>';
    for my $svc (
        ['crowdsec',                  '⚙️', 'CrowdSec Engine',    'Main detection engine — reads logs and triggers alerts'],
        ['crowdsec-firewall-bouncer', '🔥', 'Firewall Bouncer',   'Applies bans to the firewall — enforces decisions'],
    ) {
        my ($name, $ico, $label, $desc) = @$svc;
        my $st  = get_service_status($name);
        my $err = get_service_errors($name);
        my $cls = $st eq 'active'   ? 'tag active'   :
                  $st eq 'inactive' ? 'tag inactive'  : 'tag';
        my $lbl = $st eq 'active'   ? '● RUNNING'    :
                  $st eq 'inactive' ? '● STOPPED'     : '? UNKNOWN';
        print <<HTML;
  <div class="card" style="margin-bottom:14px">
    <div class="card-header">
      <div class="card-title">$ico $label
        <span class="$cls" style="margin-left:8px">$lbl</span>
      </div>
      <div style="display:flex;gap:8px">
        <form method="post" action="action.cgi"><input type="hidden" name="service" value="$name"><input type="hidden" name="action" value="start">
          <button class="btn btn-success btn-sm">▶ Start</button></form>
        <form method="post" action="action.cgi"><input type="hidden" name="service" value="$name"><input type="hidden" name="action" value="stop">
          <button class="btn btn-danger btn-sm">■ Stop</button></form>
        <form method="post" action="action.cgi"><input type="hidden" name="service" value="$name"><input type="hidden" name="action" value="restart">
          <button class="btn btn-warn btn-sm">↺ Restart</button></form>
      </div>
    </div>
    <div class="card-body">
      <p style="font-size:12px;color:#8b949e;margin-bottom:10px">$desc &nbsp;·&nbsp; <code style="font-family:var(--mono);font-size:11px;color:#e6edf3!important;background:rgba(255,255,255,.07);padding:2px 6px;border-radius:4px">$name.service</code></p>
HTML
        if ($err) {
            print qq(<div class="err-label">⚠ Recent Errors</div><div class="err-box">$err</div>);
        } else {
            print '<p style="font-size:12px;color:var(--success)">✓ No recent errors</p>';
        }
        print '</div></div>';
    }

    # ── Registered bouncers table ────────────────────────────────────────────
    my $b_cnt = scalar @$bouncers;
    print <<HTML;
  <div class="section-title" style="margin-top:8px;margin-bottom:14px">🔗 Registered Bouncers
    <span style="font-size:13px;font-weight:400;color:#6e7681">$b_cnt connected</span>
  </div>
  <div class="card">
    <div class="card-body no-pad">
HTML
    if (@$bouncers) {
        print '<table class="tbl"><thead><tr>
          <th>Name</th><th>Type</th><th>Version</th><th>IP</th><th>Last Pull</th><th>Status</th>
        </tr></thead><tbody>';
        for my $b (@$bouncers) {
            my $bname = html_escape($b->{name}       // '-');
            my $btype = html_escape($b->{type}       // '-');
            my $bver  = html_escape($b->{version}    // '-');
            my $bip   = html_escape($b->{ip_address} // $b->{ipAddress} // '-');
            my $blp   = html_escape($b->{last_pull}  // $b->{lastPull}  // '-');
            my $ok    = $b->{isValid} // $b->{is_valid} // 1;
            my $bstag = $ok ? 'tag active' : 'tag';
            my $bslbl = $ok ? 'OK' : 'REVOKED';
            print "<tr>
              <td class='mono' style='font-size:12px'>$bname</td>
              <td style='font-size:12px'>$btype</td>
              <td class='mono' style='font-size:11px'>$bver</td>
              <td class='mono' style='font-size:11px'>$bip</td>
              <td style='font-size:11px;color:#6e7681'>$blp</td>
              <td><span class='$bstag'>$bslbl</span></td>
            </tr>";
        }
        print '</tbody></table>';
    } else {
        print '<div class="no-data">No bouncers registered</div>';
    }
    print '</div></div>';
    print '</div>'; # content
}


# ─────────────────────────────────────────────────────────────────────────────
# TAB: HUB
# ─────────────────────────────────────────────────────────────────────────────
elsif ($tab eq 'hub') {
    my $hub_json = `cscli hub list -o json 2>/dev/null`;
    my $hub_data = load_json($hub_json);
    $hub_data = {} unless ref $hub_data eq 'HASH';

    my %hub_items;
    for my $key (qw(scenarios parsers collections postoverflows)) {
        $hub_items{$key} = ref $hub_data->{$key} eq 'ARRAY' ? $hub_data->{$key} : [];
    }

    my @sections = (
        ['scenarios',     '🎯', 'Scenarios',     '#6c63ff'],
        ['parsers',       '🔍', 'Parsers',        '#f5a623'],
        ['collections',   '📦', 'Collections',    '#3dd68c'],
        ['postoverflows', '📤', 'Post-overflows', '#58a6ff'],
    );

    print render_topbar("📦", "Hub", "", "hub");
    print '<div class="content">';

    # Tab buttons
    print '<div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">';
    my $first = 1;
    for my $s (@sections) {
        my ($key, $ico, $lbl, $col) = @$s;
        my $cnt  = scalar @{$hub_items{$key}};
        my $bg   = $first ? "background:rgba(108,99,255,0.15);border-color:rgba(108,99,255,0.5)"
                          : "background:var(--surface2);border-color:var(--border)";
        print <<HTML;
<button onclick="showHub('$key', this)"
  style="display:flex;flex-direction:column;align-items:flex-start;gap:4px;
    padding:14px 20px;border-radius:10px;border:1px solid;cursor:pointer;
    font-family:var(--sans);transition:all .15s;min-width:130px;$bg"
  class="hub-btn @{[$first ? 'hub-active' : '']}">
  <span style="font-size:11px;font-weight:600;color:#8b949e;text-transform:uppercase;letter-spacing:.06em">$ico $lbl</span>
  <span style="font-size:28px;font-weight:700;font-family:var(--mono);color:$col">$cnt</span>
</button>
HTML
        $first = 0;
    }
    print '</div>';

    # Content panels
    for my $s (@sections) {
        my ($key, $ico, $lbl, $col) = @$s;
        my $items   = $hub_items{$key};
        my $display = ($key eq 'scenarios') ? 'block' : 'none';
        my $cnt     = scalar @$items;
        my $active_note = ($key eq 'scenarios')
            ? qq( <span style="font-size:11px;font-weight:400;color:#6e7681">· "Active" = triggered an alert ($since_label)</span>)
            : '';
        print <<HTML;
<div id="hub-panel-$key" style="display:$display">
  <div class="card">
    <div class="card-header">
      <div class="card-title">$ico $lbl
        <span style="font-size:13px;font-weight:400;color:#6e7681;margin-left:8px">$cnt installed</span>$active_note
      </div>
    </div>
    <div class="card-body no-pad">
HTML
        my $is_sc_tab = ($key eq 'scenarios');
        if (@$items) {
            my $active_th = $is_sc_tab ? "<th>Active</th>" : '';
            print "<table class=\"tbl\"><thead><tr>
              <th>Name</th><th>Version</th><th>Status</th>$active_th<th>Description</th>
            </tr></thead><tbody>";
            for my $item (@$items) {
                my $name   = html_escape($item->{name}        // '-');
                my $ver    = html_escape($item->{version}     // $item->{local_version} // '');
                my $desc   = html_escape($item->{description} // '');
                my $status = $item->{status} // 'enabled';
                my $lv     = $item->{local_version} // '';
                my $upd    = ($lv && $ver && $lv ne $ver);
                my @statuses   = split /,/, $status;
                my $is_enabled = grep { /^enabled$/i } @statuses;
                my $is_local   = grep { /^local$/i   } @statuses;
                my $badge_html;
                if ($upd) {
                    $badge_html = "<span class='tag warn'>update available</span>";
                } else {
                    $badge_html  = $is_enabled ? "<span class='tag active'>enabled</span> " : '';
                    $badge_html .= $is_local   ? "<span style='display:inline-flex;align-items:center;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:600;background:rgba(88,166,255,0.12);color:#58a6ff;border:1px solid rgba(88,166,255,0.25)'>local</span>" : '';
                    $badge_html ||= "<span class='tag'>$status</span>";
                }
                my $ver_display = $ver || ($is_local ? '<span style="color:#6e7681">local</span>' : '-');
                my $active_td = '';
                if ($is_sc_tab) {
                    my $hits = $sc_counts->{$item->{name}} || 0;
                    $active_td = $hits
                        ? "<td><span style='display:inline-flex;align-items:center;gap:5px;font-size:11px;color:#3dd68c'><span style='width:7px;height:7px;border-radius:50%;background:#3dd68c;box-shadow:0 0 5px #3dd68c'></span>Active ($hits)</span></td>"
                        : "<td><span style='display:inline-flex;align-items:center;gap:5px;font-size:11px;color:#6e7681'><span style='width:7px;height:7px;border-radius:50%;background:#3c4454'></span>Inactive</span></td>";
                }
                print "<tr>
                  <td class='mono' style='font-size:12px'>$name</td>
                  <td class='mono' style='font-size:11px'>$ver_display</td>
                  <td style='white-space:nowrap'>$badge_html</td>
                  $active_td
                  <td style='font-size:11px;color:#8b949e'>$desc</td>
                </tr>";
            }
            print '</tbody></table>';
        } else {
            print "<div class='no-data'>No $lbl installed</div>";
        }
        print '</div></div></div>';
    }

    print <<'HTML';
<style>
.hub-btn { color: inherit; }
.hub-btn:hover { border-color: rgba(108,99,255,0.4) !important; background: rgba(108,99,255,0.08) !important; }
.hub-btn.hub-active { background: rgba(108,99,255,0.15) !important; border-color: rgba(108,99,255,0.5) !important; }
</style>
<script>
function showHub(key, btn) {
  ['scenarios','parsers','collections','postoverflows'].forEach(function(k) {
    var p = document.getElementById('hub-panel-' + k);
    if (p) p.style.display = (k === key) ? 'block' : 'none';
  });
  document.querySelectorAll('.hub-btn').forEach(function(b) {
    b.classList.remove('hub-active');
    b.style.background = 'var(--surface2)';
    b.style.borderColor = 'var(--border)';
  });
  btn.classList.add('hub-active');
  btn.style.background = 'rgba(108,99,255,0.15)';
  btn.style.borderColor = 'rgba(108,99,255,0.5)';
}
</script>
HTML
    print '</div>'; # content
}

# ─────────────────────────────────────────────────────────────────────────────
# TAB: WHITELIST
# ─────────────────────────────────────────────────────────────────────────────
elsif ($tab eq 'whitelist') {

    my $ALLOWLIST_NAME = 'webmin-temp-whitelist';

    # Success/error messages
    my $msg = '';
    if ($in{wl_added})   { $msg = qq(<div style="background:rgba(61,214,140,.08);border:1px solid rgba(61,214,140,.25);border-radius:8px;padding:10px 16px;color:#3dd68c;font-size:13px;margin-bottom:16px">✓ Whitelist entry added successfully</div>); }
    if ($in{wl_deleted}) { $msg = qq(<div style="background:rgba(61,214,140,.08);border:1px solid rgba(61,214,140,.25);border-radius:8px;padding:10px 16px;color:#3dd68c;font-size:13px;margin-bottom:16px">✓ Whitelist entry removed</div>); }
    if ($in{wl_err})     { my $e = html_escape($in{wl_err}); $msg = qq(<div style="background:rgba(255,92,92,.08);border:1px solid rgba(255,92,92,.25);border-radius:8px;padding:10px 16px;color:#ff9090;font-size:13px;margin-bottom:16px">⚠ $e</div>); }

    print render_topbar("✅", "Whitelist", "Temporary IP allowlist", "whitelist");
    print '<div class="content">';
    print $msg;

    print <<HTML;
  <!-- Add form -->
  <div class="card" style="margin-bottom:20px">
    <div class="card-header"><div class="card-title">➕ Add Whitelist Entry</div></div>
    <div class="card-body">
      <form method="post" action="action.cgi">
      <input type="hidden" name="action" value="add_whitelist">
      <div style="display:flex;gap:12px;align-items:end;flex-wrap:wrap">

        <div style="flex:1 1 260px;min-width:220px">
          <label style="display:block;font-size:11px;font-weight:600;color:#8b949e;
            text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">
            IP Address or CIDR
          </label>
          <input type="text" name="wl_ip" placeholder="e.g. 203.0.113.5 or 10.0.0.0/8"
            required pattern="^\\d{1,3}(\\.\\d{1,3}){3}(/\\d{1,2})?\$"
            style="width:100%;min-width:200px;background:#0d1117;color:#e6edf3;border:1px solid #2a3450;
              border-radius:8px;padding:9px 12px;font-family:var(--mono);font-size:13px;
              outline:none;box-sizing:border-box"
            onfocus="this.style.borderColor='rgba(108,99,255,.5)'"
            onblur="this.style.borderColor='#2a3450'">
        </div>

        <div style="flex:0 0 auto">
          <label style="display:block;font-size:11px;font-weight:600;color:#8b949e;
            text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Duration</label>
          <select name="wl_duration"
            style="background:#0d1117;color:#e6edf3;border:1px solid #2a3450;
              border-radius:8px;padding:9px 12px;font-family:var(--sans);font-size:13px;
              outline:none;cursor:pointer;min-width:140px">
            <option value="1h">1 hour</option>
            <option value="4h">4 hours</option>
            <option value="12h">12 hours</option>
            <option value="24h" selected>24 hours</option>
            <option value="48h">2 days</option>
            <option value="168h">1 week</option>
            <option value="720h">30 days</option>
            <option value="custom">Custom...</option>
          </select>
        </div>

        <div id="custom-dur-wrap" style="display:none;flex:0 0 auto">
          <label style="display:block;font-size:11px;font-weight:600;color:#8b949e;
            text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Custom duration</label>
          <input type="text" name="wl_custom_duration" placeholder="e.g. 2h30m"
            style="width:110px;background:#0d1117;color:#e6edf3;border:1px solid #2a3450;
              border-radius:8px;padding:9px 12px;font-family:var(--mono);font-size:13px;outline:none"
            onfocus="this.style.borderColor='rgba(108,99,255,.5)'"
            onblur="this.style.borderColor='#2a3450'">
        </div>

        <div>
          <label style="display:block;font-size:11px;font-weight:600;color:#8b949e;
            text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">Reason</label>
          <input type="text" name="wl_reason" placeholder="Optional note"
            style="width:160px;background:#0d1117;color:#e6edf3;border:1px solid #2a3450;
              border-radius:8px;padding:9px 12px;font-family:var(--sans);font-size:13px;outline:none"
            onfocus="this.style.borderColor='rgba(108,99,255,.5)'"
            onblur="this.style.borderColor='#2a3450'">
        </div>

        <div>
          <label style="display:block;font-size:11px;font-weight:600;color:#8b949e;
            text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">&nbsp;</label>
          <button type="submit" class="btn btn-primary" style="padding:9px 20px;white-space:nowrap">
            ✅ Add to Whitelist
          </button>
        </div>

      </div>

      <!-- Scope / service checkboxes -->
      <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border)">
        <label style="display:block;font-size:11px;font-weight:600;color:#8b949e;
          text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px">
          Apply to
        </label>
        <div style="display:flex;gap:20px;flex-wrap:wrap">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
            <input type="checkbox" name="wl_scope" value="crowdsec" checked
              style="width:16px;height:16px;accent-color:var(--accent)">
            <span>⚙️ CrowdSec Engine Allowlist</span>
            <span style="font-size:11px;color:#6e7681">(prevents new bans; the firewall bouncer automatically honors this)</span>
          </label>
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
            <input type="checkbox" name="wl_scope" value="delete_existing" checked
              style="width:16px;height:16px;accent-color:var(--accent)">
            <span>🗑 Delete existing bans for this IP</span>
          </label>
        </div>
      </div>
      </form>
    </div>
  </div>
HTML

    # ── Source 1: cscli allowlists (CrowdSec >=1.6, the modern mechanism) ──────
    my $al_inspect = `cscli allowlists inspect \Q$ALLOWLIST_NAME\E -o json 2>&1`;
    $al_inspect //= '';
    my @al_current;
    if ($al_inspect =~ /[\[\{]/) {
        my $ald = load_json($al_inspect);
        my $items = [];
        if (ref $ald eq 'ARRAY') { $items = $ald; }
        elsif (ref $ald eq 'HASH') {
            $items = $ald->{items} // $ald->{values} // $ald->{ips} // $ald->{entries} // [];
        }
        for my $it (@$items) {
            next unless ref $it eq 'HASH';
            push @al_current, {
                value      => $it->{value} // $it->{ip} // $it->{range} // '-',
                expiration => $it->{expiration} // $it->{expires_at} // '-',
                comment    => $it->{comment} // $it->{description} // '-',
            };
        }
    }

    # ── Source 2: legacy decision-based whitelist (older cscli) ────────────────
    my $wl_json2 = `cscli decisions list -t whitelist -o json 2>/dev/null`;
    $wl_json2 //= '';
    my @wl_current;
    if ($wl_json2 && $wl_json2 !~ /^\s*null\s*$/ && $wl_json2 =~ /\[/) {
        my $wld = load_json($wl_json2);
        if (ref $wld eq 'ARRAY') {
            for my $alert (@$wld) {
                next unless ref $alert eq 'HASH';
                for my $d (@{$alert->{decisions} // []}) {
                    push @wl_current, {
                        id       => $d->{id}       // '',
                        value    => $d->{value}    // $alert->{source}{ip} // '-',
                        duration => $d->{duration} // '-',
                        origin   => $d->{origin}   // '-',
                        scenario => $alert->{scenario} // $d->{scenario} // '-',
                    };
                }
            }
        }
    }

    my $al_cnt = scalar @al_current;
    print <<HTML;
  <div class="card" style="margin-bottom:20px">
    <div class="card-header">
      <div class="card-title">✅ Active Whitelist Entries</div>
      <span style="font-size:11px;color:#6e7681">$al_cnt entries · via cscli allowlists</span>
    </div>
    <div class="card-body no-pad">
HTML
    if (@al_current) {
        print '<table class="tbl"><thead><tr>
          <th>IP / Range</th><th>Expires</th><th>Note</th><th></th>
        </tr></thead><tbody>';
        for my $w (@al_current) {
            my $ip  = html_escape($w->{value}      // '-');
            my $exp = html_escape($w->{expiration}  // '-');
            my $nt  = html_escape($w->{comment}     // '');
            print <<HTML;
<tr>
  <td class="mono" style="font-weight:600">$ip</td>
  <td class="mono" style="color:#3dd68c;font-size:12px">$exp</td>
  <td style="font-size:11px;color:#6e7681">$nt</td>
  <td>
    <form method="post" action="action.cgi" style="display:inline">
      <input type="hidden" name="action" value="delete_whitelist">
      <input type="hidden" name="ip" value="$ip">
      <button class="btn btn-warn btn-sm" type="submit"
        onclick="return confirm('Remove whitelist entry for $ip?')">🗑 Remove</button>
    </form>
  </td>
</tr>
HTML
        }
        print '</tbody></table>';
    } else {
        print '<div class="no-data">No active allowlist entries — all IPs subject to normal detection</div>';
    }
    print '</div></div>';

    if (@wl_current) {
        my $wl_cnt = scalar @wl_current;
        print <<HTML;
  <div class="card" style="margin-bottom:20px">
    <div class="card-header">
      <div class="card-title">🕘 Legacy Whitelist Decisions</div>
      <span style="font-size:11px;color:#6e7681">$wl_cnt entries · via cscli decisions --type whitelist</span>
    </div>
    <div class="card-body no-pad">
      <table class="tbl"><thead><tr>
        <th>IP / Range</th><th>Expires in</th><th>Origin</th><th>Note</th><th></th>
      </tr></thead><tbody>
HTML
        for my $w (@wl_current) {
            my $ip  = html_escape($w->{value}    // '-');
            my $dur = html_escape($w->{duration} // '-');
            my $ori = html_escape($w->{origin}   // '-');
            my $sc  = html_escape($w->{scenario} // '');
            my $id  = html_escape($w->{id}       // '');
            print <<HTML;
<tr>
  <td class="mono" style="font-weight:600">$ip</td>
  <td class="mono" style="color:#3dd68c;font-size:12px">$dur</td>
  <td style="font-size:12px;color:#8b949e">$ori</td>
  <td style="font-size:11px;color:#6e7681">$sc</td>
  <td>
    <form method="post" action="action.cgi" style="display:inline">
      <input type="hidden" name="action" value="delete_whitelist">
      <input type="hidden" name="id" value="$id">
      <input type="hidden" name="ip" value="$ip">
      <button class="btn btn-warn btn-sm" type="submit"
        onclick="return confirm('Remove whitelist entry for $ip?')">🗑 Remove</button>
    </form>
  </td>
</tr>
HTML
        }
        print '</tbody></table></div></div>';
    }

    # ── Diagnostics: show exactly what the last add/remove attempt ran ─────────
    my $WL_DEBUG_FILE = ($module_config_directory || '/etc/webmin/crowdsec') . '/whitelist_debug.txt';   # root-only
    my $dbg_text = '';
    if (open(my $dfh, '<', $WL_DEBUG_FILE)) {
        local $/; $dbg_text = <$dfh>; close $dfh;
    }
    my $dbg_html = html_escape($dbg_text || '(no whitelist add/remove has been attempted yet this session)');
    print <<HTML;
  <details style="margin-top:6px">
    <summary style="cursor:pointer;font-size:12px;color:#8b949e;padding:6px 0">🔧 Diagnostics: last whitelist command output (click to expand)</summary>
    <pre style="background:#0d1117;color:#8b949e;border:1px solid #2a3450;border-radius:8px;
      padding:12px;font-size:11px;line-height:1.6;white-space:pre-wrap;margin-top:8px;max-height:400px;overflow:auto">$dbg_html</pre>
  </details>
HTML

    print <<'HTML';
<script>
// Show/hide custom duration field
document.querySelector('select[name="wl_duration"]').addEventListener('change', function() {
  var wrap = document.getElementById('custom-dur-wrap');
  wrap.style.display = this.value === 'custom' ? 'block' : 'none';
  document.querySelector('input[name="wl_custom_duration"]').required = (this.value === 'custom');
});
</script>
HTML
    print '</div>'; # content
}

# ─────────────────────────────────────────────────────────────────────────────
# TAB: WEEKLY REPORT (local version of CrowdSec's weekly security email)
# ─────────────────────────────────────────────────────────────────────────────
elsif ($tab eq 'weekly') {
    require POSIX;
    my $HIST = ($module_config_directory || '/etc/webmin/crowdsec') . '/history.jsonl';
    my $CRON = '/etc/cron.d/webmin-crowdsec-snapshot';
    snap_take($HIST, 900);                       # also record on every visit (max every 15 min)
    my $rows    = snap_load($HIST);
    my $now     = time();
    my $WEEK    = 7 * 86400;
    my $cron_on = -f $CRON;

    my ($this_w, $cov_this) = snap_delta($rows, $now - $WEEK,   $now);
    my ($prev_w, $cov_prev) = snap_delta($rows, $now - 2*$WEEK, $now - $WEEK);
    my $hist_since = @$rows ? POSIX::strftime('%d %b %Y %H:%M', localtime($rows->[0]{ts})) : '';

    my $sum_p = sub { my ($h) = @_; my $t = 0; $t += $h->{$_}{p} || 0 for grep { $_ ne '' } keys %$h; $t };
    my $prevented      = $sum_p->($this_w);
    my $prevented_prev = $sum_p->($prev_w);
    my $have_week      = $cov_this >= 6.5 * 86400;
    my $have_prev      = $cov_prev >= 6.5 * 86400;

    # Fallback while history builds up: running totals since the bouncer started
    my $live = snap_read_counters() || {};
    my $live_total = $sum_p->($live);

    # Local detections: this week vs the week before (needs >7 days retention)
    my $al14_raw = get_alerts_detail('14d');
    my $al14     = $exclude_test ? filter_alerts($al14_raw, @test_ranges) : $al14_raw;
    my ($det_this, $det_prev, $oldest) = (0, 0, $now);
    require Time::Local;
    for my $a (@$al14) {
        next unless ($a->{start_at} // '') =~ /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
        my $t = eval { Time::Local::timegm($6,$5,$4,$3,$2-1,$1) } or next;
        $oldest = $t if $t < $oldest;
        if ($t >= $now - $WEEK) { $det_this++ } else { $det_prev++ }
    }
    my $have_det_prev = $oldest < $now - 13 * 86400;

    my $fmt_k = sub { my $n = shift // 0;
        return $n >= 1e6 ? sprintf('%.1fM', $n/1e6) : $n >= 1e3 ? sprintf('%.1fk', $n/1e3) : $n };
    my $trend = sub {
        my ($cur, $prev, $ok) = @_;
        return '<span class="wk-trend muted">no previous week to compare yet</span>' unless $ok;
        return '<span class="wk-trend muted">no change from previous week</span>' if $cur == $prev;
        return '<span class="wk-trend">↑ new this week (none the week before)</span>' if !$prev;
        my $pct = ($cur - $prev) / $prev * 100;
        my $arr = $pct > 0 ? '↑' : '↓';
        return sprintf('<span class="wk-trend">%s %.0f%% vs previous week (%s)</span>', $arr, abs($pct), $fmt_k->($prev));
    };

    my $range_lbl = POSIX::strftime('%B %d', localtime($now - $WEEK)) . ' – ' . POSIX::strftime('%B %d, %Y', localtime($now));

    print render_topbar("🗓️", "Weekly Report", $range_lbl, "weekly");
    print '<div class="content">';
    if ($in{wk_ok})  { my $w = $in{wk_ok} eq 'enabled' ? 'Hourly snapshots enabled — the first one was just taken.' : 'Hourly snapshots disabled. Saved history is kept.';
                       print qq(<div class="wk-msg ok">✓ $w</div>); }
    if ($in{wk_err}) { print '<div class="wk-msg err">⚠ ' . html_escape($in{wk_err}) . '</div>'; }

    # ── Hero row ──────────────────────────────────────────────────────────────
    my ($hero_val, $hero_sub);
    if ($have_week) {
        $hero_val = $fmt_k->($prevented);
        $hero_sub = $trend->($prevented, $prevented_prev, $have_prev);
    } elsif (@$rows >= 2) {
        my $days = sprintf('%.1f', $cov_this / 86400);
        $hero_val = $fmt_k->($prevented);
        $hero_sub = qq(<span class="wk-trend muted">only $days days of history so far — a full week builds up automatically</span>);
    } else {
        $hero_val = $fmt_k->($live_total);
        $hero_sub = '<span class="wk-trend muted">running total since the bouncer last started — weekly figures need snapshot history (see below)</span>';
    }
    my $proc   = $this_w->{''}{p} || 0;
    my $share  = ($have_week || @$rows >= 2) && $proc ? sprintf('%.2f%% of all inbound packets', $prevented / $proc * 100) : '';
    my $share_html = $share ? qq(<div class="wk-tile-sub">$share</div>) : '';
    my $det_trend = $trend->($det_this, $det_prev, $have_det_prev);
    $det_trend = '<span class="wk-trend muted">CrowdSec keeps 7 days of alerts by default, so there is no previous week to compare</span>' unless $have_det_prev;
    my $det_this_k = $fmt_k->($det_this);

    print <<HTML;
  <div class="wk-hero">
    <div class="wk-tile big">
      <div class="wk-tile-label">Attacks prevented</div>
      <div class="wk-tile-value">$hero_val</div>
      <div class="wk-tile-sub">packets dropped by the firewall bouncer</div>
      $share_html
      $hero_sub
    </div>
    <div class="wk-tile">
      <div class="wk-tile-label">Attacks detected on this server</div>
      <div class="wk-tile-value">$det_this_k</div>
      <div class="wk-tile-sub">alerts raised by your own scenarios</div>
      $det_trend
    </div>
  </div>
HTML

    # ── Top attack behaviours blocked ─────────────────────────────────────────
    my $by_reason = get_active_decisions_by_reason();
    my %beh;
    for my $r (keys %$by_reason) { $beh{behaviour_label($r)} += $_ for values %{$by_reason->{$r}}; }
    my @top_beh = (sort { $beh{$b} <=> $beh{$a} || $a cmp $b } keys %beh)[0..4];
    @top_beh = grep { defined } @top_beh;
    my $beh_max = @top_beh ? $beh{$top_beh[0]} : 1;
    my $beh_total = 0; $beh_total += $_ for values %beh;

    print qq(<div class="section-title">🎯 Top Attack Behaviors Blocked
      <div class="section-sub">IPs currently on your blocklists, by the behaviour they were banned for · @{[ $fmt_k->($beh_total) ]} IPs in total</div></div>
      <div class="card"><div class="card-body">);
    if (@top_beh) {
        for my $b (@top_beh) {
            my $w = sprintf('%.1f', $beh{$b} / $beh_max * 100);
            my $lbl = html_escape($b); my $v = $fmt_k->($beh{$b});
            print qq(<div class="wk-bar-row"><div class="wk-bar-lbl" title="$lbl">$lbl</div>
              <div class="wk-bar-track"><div class="wk-bar" style="width:$w%"></div></div>
              <div class="wk-bar-val">$v</div></div>);
        }
    } else {
        print '<div class="no-data">No active decisions reported by cscli metrics</div>';
    }
    print '</div></div>';

    # ── Blocklists you receive ────────────────────────────────────────────────
    my %ips_by_origin;
    for my $r (keys %$by_reason) { $ips_by_origin{$_} += $by_reason->{$r}{$_} for keys %{$by_reason->{$r}}; }
    my $traffic = ($have_week || @$rows >= 2) ? $this_w : $live;
    my $traffic_note = ($have_week || @$rows >= 2) ? 'this week' : 'since bouncer start';
    my %orig = map { $_ => 1 } (keys %ips_by_origin, grep { $_ ne '' } keys %$traffic);
    my @origins = sort { ($traffic->{$b}{p}||0) <=> ($traffic->{$a}{p}||0) || $a cmp $b } keys %orig;
    my $tot_p = 0; $tot_p += $traffic->{$_}{p} || 0 for @origins;

    print qq(<div class="section-title">🛡️ Your Blocklists
      <div class="section-sub">Lists your server actually receives, and how much traffic each one stopped ($traffic_note)</div></div>
      <div class="card"><div class="card-body no-pad"><table class="tbl"><thead><tr>
        <th>Source</th><th style="text-align:right">Active IPs</th><th style="text-align:right">Packets dropped</th><th style="text-align:right">Data dropped</th><th style="text-align:right">Share</th>
      </tr></thead><tbody>);
    for my $o (@origins) {
        my $p = $traffic->{$o}{p} || 0;
        my $pct = $tot_p ? sprintf('%.1f%%', $p / $tot_p * 100) : '–';
        my $lbl = html_escape(origin_label($o));
        print qq(<tr><td>$lbl</td><td class="mono" style="text-align:right">@{[ $fmt_k->($ips_by_origin{$o} || 0) ]}</td>
          <td class="mono" style="text-align:right">@{[ $fmt_k->($p) ]}</td>
          <td class="mono" style="text-align:right">@{[ fmt_bytes($traffic->{$o}{b} || 0) ]}</td>
          <td class="mono" style="text-align:right">$pct</td></tr>);
    }
    print '<tr><td colspan="5" class="no-data">No blocklist data from cscli metrics</td></tr>' unless @origins;
    print '</tbody></table></div></div>';

    print <<HTML;
  <div class="wk-note">
    <strong>Premium blocklist recommendations</strong> (e.g. "Mail Server Attackers · ↘ 28% alerts") are only available in the
    <a href="https://app.crowdsec.net" target="_blank" rel="noopener">CrowdSec Console</a>. CrowdSec calculates them in the cloud by
    matching your alerts against list contents that are only delivered to subscribers, so they can't be computed on this server.
    Any blocklist you subscribe to, free or paid, appears in the table above automatically.
  </div>
HTML

    # ── History / snapshots ──────────────────────────────────────────────────
    my $n_rows  = scalar @$rows;
    my $since_t = $hist_since ? "since $hist_since" : 'none yet';
    my ($btn_act, $btn_lbl, $btn_cls, $state) = $cron_on
        ? ('disable_snapshots', 'Disable hourly snapshots', 'btn-ghost', '<span style="color:#3dd68c">● enabled</span> — runs hourly from /etc/cron.d')
        : ('enable_snapshots',  'Enable hourly snapshots',  'btn-primary', '<span style="color:#f0b429">● off</span> — only recorded when you open this tab');
    print <<HTML;
  <div class="card" style="margin-top:20px">
    <div class="card-header"><div class="card-title">🕒 Snapshot history</div>
      <span style="font-size:12px;color:#8b949e">$state</span></div>
    <div class="card-body" style="display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap">
      <div style="font-size:12px;color:#8b949e;max-width:640px">The bouncer only keeps running totals, so this tab saves a copy of them every hour
        and works out weekly figures from the differences. $n_rows snapshots $since_t; kept for 60 days.
        Trends appear once two full weeks are recorded.</div>
      <form method="post" action="action.cgi"><input type="hidden" name="action" value="$btn_act">
        <button type="submit" class="btn $btn_cls">$btn_lbl</button></form>
    </div>
  </div>
HTML
    print '</div>'; # content
}

# close main + shell
print '</div></div>'; # .main + .shell

print <<'HTML';
<script>
// ── Responsive viz-grid ───────────────────────────────────────────────────────
function applyGridLayout() {
  var grid = document.querySelector('.viz-grid');
  if (!grid) return;
  var parent = grid.parentElement;
  var w = parent ? (parent.clientWidth || parent.offsetWidth) : 0;
  if (w > 0) grid.style.gridTemplateColumns = w < 700 ? '1fr' : '1fr 1fr';
}

document.addEventListener('DOMContentLoaded', function() {
  applyGridLayout();
  if (window.ResizeObserver) {
    var content = document.querySelector('.content') || document.querySelector('.main');
    if (content) new ResizeObserver(applyGridLayout).observe(content);
  }
});
window.addEventListener('resize', applyGridLayout);

// ── Visualizer None/Summary/Expanded tabs ─────────────────────────────────────
function setViz(mode, btn) {
  document.querySelectorAll('.viz-tab').forEach(function(t) { t.classList.remove('active'); });
  btn.classList.add('active');
  var body = document.getElementById('viz-body');
  if (body) body.style.display = mode === 'none' ? 'none' : '';
  // Show summary or expanded lists
  document.querySelectorAll('.viz-summary').forEach(function(el) {
    el.style.display = (mode === 'expanded') ? 'none' : '';
  });
  document.querySelectorAll('.viz-expanded').forEach(function(el) {
    el.style.display = (mode === 'expanded') ? '' : 'none';
  });
}

// ── Source ASs card tooltip (engine ID on hover) ──────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  var asTitle = document.querySelector('.viz-card-title');
  var cards = document.querySelectorAll('.viz-card');
  var asCard = null;
  cards.forEach(function(c) {
    var t = c.querySelector('.viz-card-title');
    if (t && t.textContent.indexOf('Source AS') !== -1) asCard = c;
  });
  var tip = document.getElementById('eng-tip');
  if (asCard && tip) {
    asCard.addEventListener('mousemove', function(e) {
      var r = asCard.getBoundingClientRect();
      tip.style.display = 'block';
      tip.style.left = Math.min(e.clientX - r.left, r.width - 270) + 'px';
      tip.style.top  = (e.clientY - r.top + 16) + 'px';
    });
    asCard.addEventListener('mouseleave', function() { tip.style.display = 'none'; });
  }
});
</script>
HTML

&ui_print_footer("", "Dashboard");
